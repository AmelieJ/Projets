package HotTopic;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.*;
/**
 * Comme son nom l'indique, on g�re la cr�ation
 * et l'affichage du journal personnalis� � partir
 * des mots lik�s dans les titres d'articles et
 * de leur fr�quence
 * 
 * @author Im�ne & L�na & Vincent
 * 
 */
public class GestionJournalPerso {
	/**
	 * M�thode r�cup�rant une liste d'entiers qui repr�sentent les id des articles lik�s par l'utilisateur avec l'id id_utilisateur
	 * @param conn
	 * @param id_utilisateur
	 * @return tab_id_likes : Liste des id de journaux lik�s.
	 */
	public static List<Integer> getTabIdArticle(java.sql.Connection conn, int id_utilisateur) {
		
		List<Integer> tab_id_likes = new ArrayList<Integer>(); //cr�ation du tableau qui va contenir les id_journal
		try {
			//r�cup�ration des id_journal
			String requete2 = "SELECT id_journal FROM likes WHERE id_utilisateur = ? "; 
			PreparedStatement statement2 = conn.prepareStatement(requete2);
			statement2.setInt(1, id_utilisateur);
			ResultSet result2 = statement2.executeQuery();
			while (result2.next()) {
				//stockage des diff�rents id_journal dans la liste
				int id_journal = result2.getInt("id_journal");
				tab_id_likes.add(id_journal);
			}
		}
		catch(SQLException e) {
			e.printStackTrace();
		}
		return tab_id_likes;
	}
	
	/**
	 * M�thode r�cup�rant le titre d'un article associ� � son id
	 * 
	 * @param conn
	 * @param id
	 * @return titre_article
	 */
	public static String getTitreArticle(java.sql.Connection conn, int id) {
		
		String titre_article =""; //Cr�ation du titre de l'article lik�
		try {
			//r�cup�ration des titres
			String requete2 = "SELECT Titre_article FROM journal WHERE ID = ? "; 
			PreparedStatement statement2 = conn.prepareStatement(requete2);
			statement2.setInt(1, id);
			ResultSet result2 = statement2.executeQuery();
			while (result2.next()) {
				//stockage du titre 
				titre_article = result2.getString("Titre_article");
			
			}
		}
		catch(SQLException e) {
			e.printStackTrace();
		}
		return titre_article;
	}
	
	
	/**
	 * M�thode regroupant les deux pr�c�dentes : Tri des mots de titres d'articles avec leur fr�quence et sans doublon
	 *
	 * @param conn
	 * @param id_utilisateur
	 * @return Liste de Mots mots_final
	 */
	public static List<Mots> trierTitresLikes(java.sql.Connection conn, int id_utilisateur) {
		
		List<Mots> mots_cles = new ArrayList<Mots>(); //Cr�ation du tableau qui va contenir les mots
		List<Integer> tab_id_likes = getTabIdArticle(conn,id_utilisateur); //Tableau des id d'articles
		for (int i=0; i<tab_id_likes.size(); i++) {
			//Pour chaque id d'article : on r�cup�re son titre � partir de l'id de l'article et on ins�re les mots qui le constituent
			//et on ins�re les mots qui le constituent dans le tableau de mots
			int id_article_courant = tab_id_likes.get(i);
			String titre_article = getTitreArticle(conn,id_article_courant);
			GestionHotTopic.trierMots(titre_article, mots_cles, id_article_courant);
			
		}
		List<Mots> mots_count = GestionHotTopic.countMots(mots_cles); //On compte la fr�quence de chaque mot (en supprimant du coup les doublons)
		mots_count = GestionHotTopic.supprimerMotsInutiles(mots_count); //On supprime les mots qui "faussent" le r�sultat ("�" par ex.) en les rempla�ant par des espaces
		List<Mots> mots_final = new ArrayList<Mots>();
		mots_final = GestionHotTopic.supprimerEspace(mots_final,mots_count); //On cr�e un nouveau tableau final qui ne comportera plus les espaces
		Collections.sort(mots_final);
		return mots_final;
	}
	
	
	/**
	 * M�thode enregistrant les mots lik�s et leur fr�quence pour l'utilisateur id_utilisateur
	 * @param conn
	 * @param mots_cles
	 * @param id_utilisateur
	 */
	public static void insertionMotsLikesBase(java.sql.Connection conn, List<Mots> mots_cles, int id_utilisateur) {
		
		String mots_likes = "";
		StringBuffer mots_likes_buffer = new StringBuffer();
		
		String freq_mots_likes = ""; //Buffer qui regroupera � la suite les diff�rents mots lik�s
		StringBuffer freq_mots_likes_buffer = new StringBuffer(); //Buffer qui regroupera � la suite la fr�quence de chaque mot lik�
		
		for (int i=0; i<mots_cles.size(); i++) {
			//Construction des deux strings
			Mots mot_courant = mots_cles.get(i);
			mots_likes_buffer.append(mot_courant.getMot()+" ");
			freq_mots_likes_buffer.append(mot_courant.getFreq()+" ");
		}
		//Conversion en String des 2 buffer
		mots_likes = mots_likes_buffer.toString();
		freq_mots_likes = freq_mots_likes_buffer.toString();
		
		try {
			//Enregistrement des 2 String dans la table utilisateurs
			String requete = "UPDATE utilisateurs SET mots_likes=?, freq_mots_likes=? WHERE ID=(?)";
			PreparedStatement prestatement = conn.prepareStatement(requete);
			prestatement.setString(1,mots_likes); // attribue un coefficient d'importance au hot topic
			prestatement.setString(2, freq_mots_likes);
			prestatement.setInt(3, id_utilisateur);
			prestatement.executeUpdate();
		} 
		catch (Exception e) {
			System.out.println("Erreur enregistrement mots likes " + e);
			e.printStackTrace();
		}
		
	}
	/**
	 * 
	 * R�cup�ration des mots lik�s, tri�s avec doublon, et de leur fr�quence d'un utilisateur � partir de la base
	 * @param conn
	 * @param mots_cles
	 * @param id_utilisateur
	 */
	public static void recuperationMotsLikesBase(java.sql.Connection conn, List<MotsLikes> mots_cles, int id_utilisateur) {
		
		try {
			String requete = "SELECT mots_likes,freq_mots_likes FROM utilisateurs WHERE ID=(?)";
			PreparedStatement prestatement = conn.prepareStatement(requete);
			prestatement.setInt(1,id_utilisateur); 
			ResultSet result = prestatement.executeQuery();
			
			String mots_likes = "";
			String freq_mots_likes="";
			
			while (result.next()) {
				mots_likes = result.getString("mots_likes");
				freq_mots_likes = result.getString("freq_mots_likes");
			}
			trierMots(mots_likes, freq_mots_likes,mots_cles);
		} 
		catch (Exception e) {
			System.out.println("Erreur enregistrement mots likes " + e);
			e.printStackTrace();
		}
	}
	/**
	 * M�thode qui reconstruit � partir de 2 String, un tableau de mots lik�s avec leur fr�quence
	 * @param mots_likes
	 * @param freq_mots_likes
	 * @param tab_mots
	 */
	public static void trierMots(String mots_likes, String freq_mots_likes, List<MotsLikes> tab_mots) {
		
		int car = 0;
	    
	    List<String> list_mots = new ArrayList<String>();
	    List<Integer> list_freq = new ArrayList<Integer>();
	    int n = mots_likes.length();
	    int m = freq_mots_likes.length();
	    boolean espace = true;
	    int j;
	    
	    //M�thode manuelle de r�cup�ration des mots lik�s � partir d'un String
	    while (car<n) {
	    	j = 0;
	    	String nouveau = "";
	    	while (mots_likes.charAt(car+j) != ' ' || car == n) {
	    		espace = false;
	    		nouveau = nouveau + mots_likes.charAt(car+j);
	    		j++;
	    	}
	    	if (espace == false) {
	    		list_mots.add(nouveau);
	    		espace = true;
	    		car = car + j;
	    		j = 0;
	    	}
	    	else {
	    		j++;;
	    	}
	    	car = car + j;
	    }
	    car=0;
	    // recup�ration manuelle des fr�quences des mots lik�s � partir d'un String
	    while (car<m) {
	    	j = 0;
	    	int freq;
	    	String prov="";
	    	while (freq_mots_likes.charAt(car+j) != ' ' || car == n) {
	    		espace = false;
	    		prov = prov + freq_mots_likes.charAt(car+j);
	    		j++;
	    	}
	    	if (espace == false) {
	    		list_freq.add(Integer.parseInt(prov));
	    		espace = true;
	    		car = car + j;
	    		j = 0;
	    	}
	    	else {
	    		j++;;
	    	}
	    	car = car + j;
	    }
	    
	    int t=list_freq.size();
	    for (int i=0; i<t; i++) {
	    	//Pour chaque mot lik�, on lui associe son String et sa fr�quence et on les rentre dans la liste
	    	MotsLikes nouveau = new MotsLikes(list_mots.get(i),list_freq.get(i));
	    	tab_mots.add(nouveau);
	    }
	    
	}
	/**
	 * Affichage des mots lik�s d'un tableau
	 * @param mots
	 */
	public static void afficherMots(List<MotsLikes> mots) {
		
		for (int i=0; i<mots.size(); i++) {
			System.out.print("mot num�ro "+(i+1)+" : ");
			 mots.get(i).afficherMot();
		}
	}
	/**
	 * Affichage du journal perso avec 2 articles pour chaque mot lik� (4 mot lik� maximum)
	 * @param conn
	 * @param list
	 * @param id_utilisateur
	 */
	public static void afficherJournalPerso(java.sql.Connection conn, List<MotsLikes> list,  int id_utilisateur) {
		
		List<Mots> mots_base = new ArrayList<Mots>();
		mots_base = GestionHotTopic.trierTitresBase(conn); //On r�cup�re les titres d'articles dans la base qui date de moins d'un jour
		Mots dernier_mot = new Mots();
		mots_base.add(dernier_mot); //Pour �viter les probl�mes de gestion de taille de la liste
		
		int m = mots_base.size();
		int n = list.size();
		int tab[] = new int[9]; // tableau contenant les valeurs d'abonnement (de 0 � 9 pour les 10 journaux)
		int cpt_like = 0;
		
		try{
			//R�cup�ration de la liste d'abonnements de l'utilisateur
			String requete = "SELECT abonnement FROM utilisateurs WHERE ID = ?";
			PreparedStatement statement = conn.prepareStatement(requete); 
			statement.setInt(1, id_utilisateur);
			ResultSet result = statement.executeQuery();
			String abonnement ="";
			
			while (result.next()) {
				abonnement = result.getString("abonnement");
				for (int f=0; f<9; f++) {
					tab[f]=+abonnement.charAt(f)-48; //On convertit la liste des id_journaux 123.. en int 1, 2, 3
				}
			}
		}
		catch(SQLException e){ e.printStackTrace();}
			
		int i = 0;
		List<Integer> tab_id_abonnement = new ArrayList<Integer>();
		while (i<n && cpt_like<4) { //Nombre de mots lik�s affich�s par d�faut = 4
			//On r�cup�re le mot lik� � la position i de la liste de mots lik�s
			MotsLikes mot_courant = list.get(i); 
			String nom_courant = mot_courant.getMot();
			int j = 0;
			while (!nom_courant.equals(mots_base.get(j).getMot()) && j<m -1) {
				//Tant que le nom courant de notre liste de mots lik�s est diff�rent d'un mot contenue de notre liste de titres
				j++;
			}
			
			if (j!=m) { //Si on a trouv� une similitude entre deux mots,
				List<Integer> tab_id = new ArrayList<Integer>(); //Cr�ation d'un tableau d'id de journaux
				tab_id = mots_base.get(j).getContentTabId();
				//On r�cup�re la table des id du mot � la position j de la liste des mots de la base 
				//pour choisir parmi eux, par la suite, quels articles afficher
				int k=0;
				int cpt=0;
				int affichage = tab_id.size();
				if (affichage - 2 > 0) {
					affichage = 2; //Si il y a plus de 2 id associ�s � un mot, on d�cide d'afficher que 2 articles maximum (choix par d�faut)
				}
				while (k<tab_id.size() && cpt<affichage) {
					int id_courant = tab_id.get(k); //On r�cup�re l'id de l'article � la position k du tableau d'id
					int h=0; //Cr�ation d'un entier qui repr�sente l'id du journal
					tab_id_abonnement.add(0); //Pour �viter les probl�mes de gestion de taille de la liste
					while (id_courant!=tab_id_abonnement.get(h) && h<tab_id_abonnement.size()-1) {
						//Tant que l'id de l'article contenant le mot en question est diff�rent du l'id de l'article � la position h 
						//et qu'on n'a pas parcouru tout le tableau, on incr�mente h
						h++;
					}
					if (h==tab_id_abonnement.size()-1) {  //Si on n'a pas de doublon
						try {
							tab_id_abonnement.add(id_courant);
							// recupere uniquement les articles des journaux auxquels l'utilisateur est abonn�:
							String requete2 = "SELECT * FROM journal WHERE (id_journal = ? OR id_journal = ? OR id_journal = ? OR id_journal = ? OR id_journal = ? OR id_journal = ? OR id_journal = ? OR id_journal = ? OR id_journal = ?) AND ID = ? ";
							PreparedStatement statement2 = conn.prepareStatement(requete2); 
							statement2.setInt(1, tab[0]);
							statement2.setInt(2, tab[1]);
							statement2.setInt(3, tab[2]);
							statement2.setInt(4, tab[3]);
							statement2.setInt(5, tab[4]);
							statement2.setInt(6, tab[5]);
							statement2.setInt(7, tab[6]);
							statement2.setInt(8, tab[7]);
							statement2.setInt(9, tab[8]);
							statement2.setInt(10,tab_id.get(k));
							ResultSet result2 = statement2.executeQuery();
							k++;
							while(result2.next() && cpt<affichage){
								if (cpt == 0) {
									cpt_like++; //Une incr�mentation correspond � au moins deux articles qui vont �tre affich�s pour un mot lik�
									System.out.println(" ");
									System.out.println("****************************");
									System.out.println("Mot cl� : " + nom_courant + " cpt_like : "+ cpt_like);
									
								}
								//Affichage des infos de l'article:
								System.out.println("---------------------------");
								System.out.println("Num�ro de l'article: " + result2.getInt("ID"));
								System.out.println("    Journal: " + result2.getString("nom_journal"));
								System.out.println("	Titre de l'article: "+ result2.getString("Titre_article") ); 
								System.out.println("	Description: "+ result2.getString("Description"));
								cpt++;
							}
						
						} catch (Exception e) {e.printStackTrace();}
					}
				
				}
			}
			i++;
		} 
	}
}
