package HotTopic;

import java.util.ArrayList;
import java.util.List;

/***
 * Classe cr�ant les Mots d'articles lik�s r�pertori�s avec leur fr�quence
 * @version 8.3
 * @author Vincent, L�na
 *
 */
public class MotsLikes {

	String mot;
	private int freq;
	
	public MotsLikes() {
		mot = "";
		freq = 1;
	}
	
	public MotsLikes(String Mot, int Freq) {
		mot = Mot;
		freq = Freq;
	}
	
	public String getMot() {
		return mot;
	}
	
	public void setMot(String Mot) {
		mot = Mot;
	}
	
	public int getFreq() {
		return freq;
	}
	
	public void setFreq(int Freq) {
		freq=Freq;
	}
	
	public void afficherMot() {
		System.out.println(mot + " est contenu " + freq + " fois");
	}
	
	
}
