package HotTopic;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.*;
/**
 * 
 * Classe de Tests pour les m�thodes de Gestion des HotTopic
 *
 */
public class TestGestionHotTopic {

	public static void main (String args []) {
		try{
		Class.forName("com.mysql.jdbc.Driver").newInstance();
		java.sql.Connection conn;
		conn = java.sql.DriverManager.getConnection(
				"jdbc:mysql://localhost:3306/test", "root", "");
		System.out.println("Connexion r�ussie  !!!");
		System.out.println(" ");
		
		GestionHotTopic test = new GestionHotTopic();
		List<Mots> mots = new ArrayList<Mots>();
		mots = test.trierTitresBase(conn);
		//test.afficherMots(mots);
		int parametre = 10; // correspond au nombre de mots-cl�s qui apparaissent dans les hot topics
		test.insertionBase(conn,mots,parametre);
		test.afficherHotTopic(conn,parametre);
		
		
		}
		catch (Exception e) {
			System.out.println("Erreur:" + e);
		}
		
	}
	
}
