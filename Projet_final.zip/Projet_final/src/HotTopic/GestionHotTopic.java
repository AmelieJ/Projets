package HotTopic;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.*;

/**
 * NomsPropres est la classe permettant le rep�rage des Hot-Topics 
 * du moment, leur enregistrement dans la base et leur affichage
 * 
 * @author Vincent & Im�ne & L�na
 * @version 8.2
 */
public class GestionHotTopic {
	
	/**
	 *  Cr�e une liste avec les mots-cl�s correspondants aux hot-topics class�s par ordre d'importance,
	 *   et les id des articles correspondants
	 * 
	 * @param conn pour la connexion
	 * @return List<Mots> 
	 */
	public static List<Mots> trierTitresBase(java.sql.Connection conn) {
		// cr�ation des listes utilis�es
		List<Mots> mots = new ArrayList<Mots>();
		List<Mots> mots_count = new ArrayList<Mots>();
		List<Mots> mots_final = new ArrayList<Mots>();
		
		try {
			// r�cup�re les informations sur les articles qui datent de moins d'un jour
			int nbjours = 1;
			Calendar now = Calendar.getInstance(); //d�finition de la date courante
			now.set(Calendar.DAY_OF_MONTH,now.get(Calendar.DAY_OF_MONTH)-nbjours);
			
			//d�finition du format de la date
			SimpleDateFormat sdf = new SimpleDateFormat("E, d MMMM yyyy H:m:s z", Locale.ENGLISH); //d�finition du format de la date
			SimpleDateFormat sdf2 = new SimpleDateFormat("E, d  MMMM yyyy H:m:s Z", Locale.ENGLISH);
			SimpleDateFormat sdf3 = new SimpleDateFormat("E, d MMMM yyyy H:m:s Z", Locale.ENGLISH);
			
			// requete vers la bdd
			Statement statement = conn.createStatement();
			ResultSet result = statement.executeQuery("SELECT Titre_article, ID, id_journal, Date FROM journal");
			String titre="";
			int id_journal;
			int id;
			// verification de la date:
			Calendar cal = Calendar.getInstance();
			
			// r�cup�ration des donn�es depuis la bdd
			while (result.next()) {
				titre = result.getString("Titre_article");
				id = result.getInt("ID");
				id_journal = result.getInt("id_journal");
				
				
				try {  // r�cup�ration de la date - format diff�rent selon le journal
					if (id_journal ==2 ) {
						cal.setTime(sdf2.parse(result.getString("Date")));
					}
					else if (id_journal ==3) {
						cal.setTime(sdf3.parse(result.getString("Date")));
					}
					else  cal.setTime(sdf.parse(result.getString("Date")));   //transforme le string en �l�ment calendar
				} catch (ParseException e) {
					System.out.println("Erreur recuperation date");
				} 
		
				if (now.compareTo(cal)==-1)  {     //si l'article est paru depouis moins d'un jour on le garde
					trierMots(titre, mots, id);   // premier tri
				}	
			}
		} 
		catch (SQLException e) {
			System.out.println("Erreur recuperation titres: " + e);
			}
		mots_count = countMots(mots);  // supprime les doublons, determine la fr�quence
		mots_count = supprimerMotsInutiles(mots_count);  // remplace les mots blancs par des espaces
		mots_final = supprimerEspace(mots_final,mots_count);  // cr�� une nouvelle liste en enlevant les champs sans mots
		Collections.sort(mots_final);  // trie par ordre d�croissant de fr�quence
		//afficherMots(mots_final);
		return mots_final;  // on obtient une liste avec tous les hots topics class�s et les id des journaux correspondants
	}
	
	
	/**
	 * Cr�e des �l�ments de classe Mots � partir de chaque mot du titre  
	 * et les rajoute dans une liste de Mots
	 * 
	 * @param titre : String correspondant au titre de l'article r�cuper� dans la base
	 * @param id_journal
	 * @param mots : Liste d'�l�ments de classe Mots (modifi�e dans la m�thode)
	 */
	public static void trierMots(String titre, List<Mots> mots, int id_journal) {
		int car = 0;
	    String mot = "";
	    titre = titre + " ";
	    
	    // pr�traitement qui enl�ve toute la ponctuation des titres d'articles
	    titre=titre.toLowerCase();
	    titre = titre.replace(",","");
	    titre = titre.replace(";","");
	    titre = titre.replace("?","");
	    titre = titre.replace("!","");
	    titre = titre.replace("(","");
	    titre = titre.replace(")","");
	    titre = titre.replace("\"","");
	    titre = titre.replace(":","");
	    titre = titre.replaceAll("\'"," "); 
	    titre = titre.replaceAll("�"," ");
	    titre = titre.replaceAll("�",""); 
	    titre = titre.replaceAll("�",""); 
	    titre = titre.replaceAll("\'","");
	    
	    titre = titre.replaceAll("-"," ");
	    titre = titre.replaceAll("[0-9]","");
	    
	    int n = titre.length();
	    boolean espace = true;
	    int j;
	    
	    //M�thode manuelle de r�cup�ration des mots   (possibilit� d'utiliser split? voir en refactoring)
	    while (car<n) {
	    	j = 0;
	    	Mots nouveau_mots = new Mots();
	    	String nouveau = nouveau_mots.getMot();
	    	while (titre.charAt(car+j) != ' ' || car == n) {
	    		espace = false;
	    		nouveau = nouveau + titre.charAt(car+j);  // on enregistre dans un string interm�diaire les caract�res jusqu'� la fin du mot
	    		j++;
	    	}
	    	if (espace == false) {  //quand le mot est termin�, 
	    		espace = true;
	    		nouveau_mots.setMot(nouveau);
	    		nouveau_mots.setTabId(id_journal);   //enregistre l'id de l'article 
	    		mots.add(nouveau_mots); //on enregistre le nouvel �l�ment Mots dans la liste mots 
	    		car = car + j;
	    		j = 0;
	    	}
	    	else {   // on continue tant que le mot n'est pas fini
	    		j++;;
	    	}
	    	car = car + j;
	    }
	}
	
	/**
	 * Enl�ve les doublons dans la liste et d�termine la fr�quence de chaque mot
	 * @param mots
	 * @return mots_count
	 */
	public static List<Mots> countMots(List<Mots> mots) {
		List<Mots> mots_count = new ArrayList<Mots>();
		for (int i=0; i<mots.size(); i++) {    // pour chaque �l�ment Mots de la liste
			Mots mot_courant = (Mots) mots.get(i);
			String nom_courant = mot_courant.getMot();
			int nbr_courant = mot_courant.getFreq();
			List<Integer> tab_id_courant= new ArrayList<Integer>();
			tab_id_courant = mot_courant.getContentTabId();
			
			
			for (int j=i+1; j<mots.size(); j++) {  // on regarde les mots suivants
				Mots mot_comparaison = (Mots) mots.get(j);
				String nom_comparaison = mot_comparaison.getMot();
				if (nom_courant.equals(nom_comparaison) == true && nom_comparaison != " ") {
					int nbr_comparaison = mot_comparaison.getFreq();
					nbr_courant = nbr_courant + nbr_comparaison;   // on incr�mente la fr�quence
					tab_id_courant.add(mot_comparaison.getContentTabId().get(0));
					mot_comparaison.setMot(" ");//on remplace le doublon par un espace
				}
			}
			Mots mot_count = new Mots(nom_courant,nbr_courant, tab_id_courant);
			mots_count.add(mot_count);  // on ajoute le mot modifi� � une nouvelle liste
		}
		return mots_count;
	}
	
	/**
	 * 
	 * Enum�ration des mots � ne pas prendre en compte dans notre liste des mots de hotTopics
	 *
	 */
	public enum BlackList {   // liste des mots-blancs � supprimer de notre liste
		le,la,les,l,un,une,des,de,en,pour,d,dans,�,au,aux,et,sur,du,par,sa,son,ses,leur,a,est,fait,pas,avec,ce,
		cette,on, qui,j,que,qu,ont,se,je,f,nous,il,elle,s,quoi,ou,o�,vous,mais,ne,encore,e,sans,toi,plus,contre,
		ensuite,the,n,deux,trois,quatre,cinq,six,sept; 
		} 
	
	
	/**
	 * Supprime les mots blancs de la liste
	 * @param mots_count avec les mots inutiles
	 * @return mots_count sans les mots inutiles
	 */
	public static List<Mots> supprimerMotsInutiles(List<Mots> mots_count) { 
		// pour supprimer tous les mots (articles et autres) qui ne correspondent pas � un sujet 
		// et pourraient fausser le r�sultat 
		int n = mots_count.size(); 
		for (int i=0; i<n; i++) 
		{ 
			// on parcourt la liste Mots 
			Mots mot_courant =mots_count.get(i); 
			String nom_courant = mot_courant.getMot(); //recuperation de la valeur mot de l'objet mot

		// comparaison avec l enumeration des mots � enlever 
			for(BlackList art : BlackList.values()){ 
				if(nom_courant.equals(art.name())) { 
					mot_courant.setMot(" "); 
					mots_count.set(i,mot_courant); 
				} 
			} 
		} 
		return mots_count; 
	}
	
	/**
	 * cr�� une nouvelle liste dans laquelle on a supprim� tous les champs o� le mot est " "
	 * @param mots_final
	 * @param mots
	 * @return mots_final sans les espaces
	 */
	public static List<Mots> supprimerEspace(List<Mots> mots_final, List<Mots> mots) {
		int n = mots.size();
		int i = 0;
		for (i=0; i<n; i++) {
			Mots mot_courant = (Mots) mots.get(i);
			String nom_courant = mot_courant.getMot();
			if (nom_courant != " ") {
				mots_final.add(mot_courant);
			}
		}
		return mots_final;
	}
	
	/**
	 * Insere dans la table journal des coefficients correspondant � l'importance du HotTopic	
	 * @param conn
	 * @param mots_final
	 * @param parametre
	 */
	public void insertionBase (java.sql.Connection conn,List<Mots> mots_final, int parametre) {
	// on remet � 0 le champ hot-topic de tous les articles pour mettre � jour
		try {
			String requete = "UPDATE journal SET HotTopic=0";
			PreparedStatement prestatement = conn.prepareStatement(requete);
			prestatement.executeUpdate();
			System.out.println("enregistrement zero reussi !!!!  =) ");
		} 
		catch (Exception e) {
			System.out.println("Erreur enregistrementn zero " + e);
		}
		// Ajout des nouvelles valeurs:
		List<Integer> liste_id = new ArrayList<Integer>();
		int taille = liste_id.size();
		for (int i=0;i<parametre;i++) {
			Mots mot_courant = mots_final.get(i);
			for (int j=0; j<mot_courant.getContentTabId().size(); j++) {
				int k=0;
				boolean doublon = false;
				while (doublon == false && k<taille) {
					if (mot_courant.getContentTabId().get(j) != liste_id.get(k)) {
						k++;
					}
					else {
						doublon = true;
					}
				}
				if (doublon==false) {
					liste_id.add(mot_courant.getContentTabId().get(j));
					try {
						String requete = "UPDATE journal SET HotTopic=? WHERE ID=(?)";
						PreparedStatement prestatement = conn.prepareStatement(requete);
						prestatement.setInt(1, parametre-i); // attribue un coefficient d'importance au hot topic
						prestatement.setInt(2, liste_id.get(taille));
						prestatement.executeUpdate();
						//System.out.println("enregistrement hotTopic reussi !!!!  =) ");
					} 
					catch (Exception e) {
						System.out.println("Erreur enregistrement hotTopic " + e);
					}
					taille++;
				}
			}
		}
	}
	
	/**
	 * R�cup�re les donn�es de la base et affiche 3 articles par HotTopic par HotTopic
	 * @param conn
	 * @param parametre
	 */
	public static void afficherHotTopic(java.sql.Connection conn, int parametre) {
		try{
			for (int j=parametre; j>0; j--) {
				String requete2 = "SELECT * FROM journal WHERE HotTopic = ? ";
				PreparedStatement statement2 = conn.prepareStatement(requete2);
				statement2.setInt(1, j);
				ResultSet result2 = statement2.executeQuery();
				if (result2.first()) { // teste si il y a des articles pour ce mot-cl�
					result2.beforeFirst(); // on revient au premier article
					System.out.println("*************************");
					System.out.println("Articles d'importance "+j);
					System.out.println("*************************");
					System.out.println();
					int cpt=0;  // compteur pour afficher max 3 articles par HotTopic
					int[] tab_id_journal = new int[3];
					while(result2.next() && cpt<3) {
						// affichage de l'article:
						tab_id_journal[cpt] = result2.getInt("id_journal");
						int k = 0;
						while ((k<cpt && tab_id_journal[cpt] != tab_id_journal[k]) && cpt != 0) {
							k++;
						}
						if (cpt == 0 || k == cpt) {
							System.out.println("	Num�ro de l'article: " + result2.getInt("ID"));
							System.out.println("    	Journal: " + result2.getString("nom_journal"));
							System.out.println("    	Date: " + result2.getString("Date"));
							System.out.println("		Titre de l'article: "+ result2.getString("Titre_article") );
							System.out.println("		---------------------------");
							System.out.println("		Description: "+ result2.getString("Description"));
							System.out.println("	---------------------------");
							System.out.println();
							cpt++;
						}
					}
					
					// on affiche de preference des articles de journaux differents
					// sinon on reprend des articles du meme journal
					if (cpt != 3) {
						int reste = 3 - cpt;
						if (reste == 2) {
							result2.first();
						}
						else {
							result2.first();
							result2.next();
						}
						cpt = 0;
						while (result2.next() && cpt<reste) {
							System.out.println("	Num�ro de l'article: " + result2.getInt("ID"));
							System.out.println("    	Journal: " + result2.getString("nom_journal"));
							System.out.println("    	Date: " + result2.getString("Date"));
							System.out.println("		Titre de l'article: "+ result2.getString("Titre_article") );
							System.out.println("		---------------------------");
							System.out.println("		Description: "+ result2.getString("Description"));
							System.out.println("	---------------------------");
							System.out.println();
							cpt++;
						}
					}
				}
			}
		}
		catch(SQLException e){ e.printStackTrace();}
	}
	
	/**
	 * Retourne la taille de la liste mots
	 * @param mots
	 * @return taille
	 */
	public static int getTaille(List<Mots> mots) {
		return mots.size();
	}
	
	/**
	 * Affiche les �l�ments de la liste mots
	 * @param mots
	 */
	public static void afficherMots(List<Mots> mots) {
		for (int i=0; i<mots.size(); i++) {
			System.out.print("mot num�ro "+(i+1)+" : ");
			 mots.get(i).afficherMot();
		}
	}	
}
