package HotTopic;

import java.util.ArrayList;
import java.util.List;
/**
 * La Classe Mots permet de'effectuer des traitements statistiques comme la fr�quence d'apparition d'un mot dans un texte.
 *
 */
public class Mots implements Comparable{
	
	String mot;
	private int freq;
	private List<Integer> tab_id;
	
	/**
	 * Constructeur sans param�tres, initialisant la frequence � 1 et instanciant un ArrayList d'entier
	 */
	public Mots() {
		mot = "";
		freq = 1;
		tab_id = new ArrayList<Integer>();
	}
	/**
	 * Constructeur initialisant les attributs d'un Mot � ceux passer en param�tres
	 * @param Mot
	 * @param Freq
	 * @param Tab_id
	 */
	public Mots(String Mot, int Freq, List<Integer> Tab_id) {
		mot = Mot;
		freq = Freq;
		tab_id = Tab_id;
	}
	
	/**
	 * Saisit un mot
	 * @return mot
	 */
	public String getMot() {
		return mot;
	}
	
	public void setMot(String Mot) {
		mot = Mot;
	}
	
	public int getFreq() {
		return freq;
	}
	
	public void setTabId(int id) {
		tab_id.add(id);
	}
	
	/**
	 * Saisit la liste des ID des articles o� le mot apparait
	 * @return Liste des Id
	 */
	public List<Integer> getContentTabId() {
		//int id_i = tab_id.get(i);
		//return id_i;
		return tab_id;
	}
	
	/**
	 * Affiche la Liste des Id des articles o� apparait un mot donn�
	 */
	public void afficherTabId() {
		System.out.print("[");
		boolean premier = true;
		for (int i=0; i<tab_id.size(); i++) {
			if (premier == true) {
				System.out.print(tab_id.get(i));
				premier = false;
			}
			else {
				System.out.print(","+tab_id.get(i));
			}
		}
		System.out.print("]");
		System.out.println();
	}
	
	public void afficherMot() {
		System.out.println(mot + " est contenu " + freq + " fois" + " dans les articles " + tab_id);
	}

	/**
	 * Compare la fr�quence d'un mot
	 * @return 0 si sa fr�quence �gale � celle du mot, -1 si elle lui est sup�rieure, 1 sinon.
	 */
	@Override
	public int compareTo(Object mot) {
		if (this.getFreq()>((Mots) mot).getFreq()) {
			return -1;
		}
		else if (this.getFreq() == ((Mots) mot).getFreq()) {
			return 0;
		}
		else {
			return 1;
		}
	}
	
	
}
