
package model;

import java.util.ArrayList;
import java.util.List;
/**
 * 
 * Liste des m�thodes permettant de r�cup�rer les informations relatives aux flux RSS. On r�cup�re une liste de flux puis les reconstitue pour les afficher ensuite dans la console.
 *
 */
public class ListeFlux {

  public final String title;
  final String link;
  final String description;
  final String language;
  final String copyright;
  final String pubDate;

  public final static List<MessageFlux> entries = new ArrayList<MessageFlux>();
/**
 * Constructeur initialisant un Flux suivant ses caract�ristiques pass�es en param�tres.
 * @param title : titre du journal
 * @param link : lien du flux
 * @param description : description de l'article
 * @param language : langue du flux
 * @param copyright 
 * @param pubDate : date de publication
 */
  public ListeFlux(String title, String link, String description, String language, String copyright, String pubDate) {
    this.title = title;
    this.link = link;
    this.description = description;
    this.language = language;
    this.copyright = copyright;
    this.pubDate = pubDate;
  }

  /**
   * Renvoie la liste des MessageFlux.
   * @return entries : liste des Messages contenus dans les flux
   */
  public List<MessageFlux> getMessages() {
    return entries;
  }
/**
 * 
 * @return title : titre du journal
 */
  public String getTitle() {
    return title;
  }
/**
 * 
 * @return link : lien de l'article
 */
  public String getLink() {
    return link;
  }
/**
 * 
 * @return description de l'article
 */
  public String getDescription() {
    return description;
  }
/**
 * 
 * @return language : la langue du flux
 */
  public String getLanguage() {
    return language;
  }
/**
 * Retourne un String correspondant au copyright du flux
 * @return copyright
 */
  public String getCopyright() {
    return copyright;
  }
/**
 * 
 * @return pubDate : date de publication de l'article
 */
  public String getPubDate() {
    return pubDate;
  }

  @Override
  public String toString() {
    return "ListeFlux [copyright=" + copyright + ", description=" + description
        + ", language=" + language + ", link=" + link + ", pubDate="
        + pubDate + ", title=" + title + "]";
  }

} 