package model;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.URL;
import java.net.URLConnection;
import java.util.logging.Level;
import java.util.logging.Logger;
//import java.lang.Object;
//import java.util.Vector;

import java.util.regex.*;

/**
 * 
 * Classe Recup_article r�cup�re le contenu d'un article issu du doc xml g�n�r� par fivefilters.org
 * 
 *
 */
public class Recup_article {
	/**
	 * R�cup�re l'article � partir de son url
	 * @param _url
	 * @return sb.toString()
	 */
	 public static String getTextFile(String _url) {
	        BufferedReader reader = null;
	        try {
	            URL url = new URL(_url);
	            URLConnection urlConnection = url.openConnection();
	            reader = new BufferedReader(new InputStreamReader(urlConnection.getInputStream()));
	            StringBuilder sb = new StringBuilder();
	            String line = null;
	            while ((line = reader.readLine()) != null) {
	                sb.append(line);
	                sb.append("\n");
	            }
	            return sb.toString();
	        } catch (IOException ex) {
	            Logger.getLogger(Recup_article.class.getName()).log(Level.SEVERE, null, ex);
	            return "";
	        } finally {
	            try {
	                if (reader != null) {
	                    reader.close();
	                }
	            } catch (IOException ex) {
	                Logger.getLogger(Recup_article.class.getName()).log(Level.SEVERE, null, ex);
	            }
	        }
	    }
	 /**
	  * R�cup�re l'article en sortie de la mise en forme de fivefilters.org apr�s un traitement manuel de certains caract�res et balises
	  * @param lien : lien du flux de l'article
	  * @return aprestri : String contenant le texte de l'article uniformis�.
	  */
	 public String getcontent(String lien) {
		 String aprestri = "";
		 try {
		 String lienfivefilters = "http://ftr.fivefilters.org/makefulltextfeed.php?url="+lien;
		 String code = getTextFile(lienfivefilters);  //passe par le site internet fivefilters pour harmoniser le code source des differents journaux
		 
		 Pattern p=Pattern.compile("<description>(.*)</description>");
		 Pattern p2=Pattern.compile("<description>(.*)</description>");
		 
		 Matcher m = p.matcher(code); //correspond au lien du journal d origine
		 
		 
		 String mauvais = "";
		 int stop=0;
		 while(m.find() && stop<1) 
 		{
 			mauvais = m.group(1);
 			//System.out.println("mauvais:"+mauvais);
 			stop++;
 		}
		
		 code =code.replace(mauvais,"");
		 code =code.replace("<description></description>","");
		 code =code.replaceAll("[\r\n]+", " ");
		 //System.out.println(code);
		 
		 // on a enlev� la premi�re partie descrption. La deuxieme est la bonne.
		 
		 Matcher m2 = p2.matcher(code); 
		 String avanttri = ">";
		
		 while(m2.find()) 
 		 {
 			avanttri = avanttri + m2.group(1);
 		 }
		 //System.out.println("texte sans balise: "+avanttri);
		 
		 avanttri = avanttri.replace("&lt;", "<");
		 avanttri = avanttri.replace("&gt;", ">");
		 avanttri = avanttri.replace("&amp;", "&");
		 avanttri = avanttri.replace("&apos;", "'");
		 
		 //System.out.println("texte avec balises: "+avanttri);
		 
		 // Insertion des paragraphes
		 avanttri = avanttri.replace("<br>", "retourALaLigne");
		 avanttri = avanttri.replace("<br/>", "retourALaLigne");
		 avanttri = avanttri.replace("<p>", "retourALaLigne");
		 avanttri = avanttri.replace("</div>", "retourALaLigne");
		 
		 //System.out.println("texte avec retours a la ligne: "+avanttri);
		 
		// on enl�ve toutes les balises du code source
	  
	    int car=0;
	    int n = avanttri.length();
	    //System.out.println("taille: "+n);
	   
	    while (car<n-1) {
	    	if (avanttri.charAt(car) == '>') {
	    		car=car+1;
	    		while (avanttri.charAt(car) != '<') {
	    			aprestri = aprestri + avanttri.charAt(car);
	    			car = car+1;
	    		}
	    	}
	    	else car=car+1;
	    }
	    
	    //System.out.println("texte tout bien tri�: "+aprestri);
		 
	    aprestri = aprestri.replace("é", "�");
	    aprestri = aprestri.replace("’", "'");
	    aprestri = aprestri.replace("è", "�");
	    aprestri = aprestri.replace("«", "�");
	    aprestri = aprestri.replace("»", "�");
	    aprestri = aprestri.replace("…", "...");
	    aprestri = aprestri.replace("�", "�");
	    aprestri = aprestri.replace("ê", "�");
	    aprestri = aprestri.replace("�", "�");
	    aprestri = aprestri.replace("��", "E");
	    aprestri = aprestri.replace("�", "�");
	    aprestri = aprestri.replace("&amp;", "&");
	    aprestri = aprestri.replace("��", "E");
	    aprestri = aprestri.replace("&mdash;", "_");
	    
	    // NOUVEAUX:
	    aprestri = aprestri.replace("“", "�");
	    aprestri = aprestri.replace("œ", "oe");
	    aprestri = aprestri.replace("��", "A");
	    aprestri = aprestri.replace("�", "�");
	    aprestri = aprestri.replace("� ", " ");
	    
	    aprestri = aprestri.replace("�", "a");
	    aprestri = aprestri.replace("œ", "oe");
	    aprestri = aprestri.replace("��", "A");
	    
	    aprestri = aprestri.replace("This entry passed through the Full-Text RSS service _ if this is your content and you're reading it on someone else's site, please read the FAQ at fivefilters.org/content-only/faq.php#publishers.","");
		 }
		 catch (Exception e) {
			 System.out.println("Erreur: R�cup�ration de l'article" +e);
			 e.printStackTrace();
		 }
		 
	    
	    //System.out.println("contenu: "+aprestri);
	    
		return aprestri;
	 }
}
