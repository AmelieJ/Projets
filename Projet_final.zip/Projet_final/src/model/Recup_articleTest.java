package model;

import org.junit.Test;

//import static org.junit.Assert.*;
//import tests.Test;
/**
 * Teste la r�cup�ration des articles
 * @version 2
 *
 */
public class Recup_articleTest {

	@Test
	public void test() {
		Recup_article article = new Recup_article();
		//String lien ="http://www.lequipe.fr/Football/Actualites/-on-n-a-pas-vole-nos-points/421869";
		String lien ="http://ftr.fivefilters.org/makefulltextfeed.php?url=http://www.liberation.fr/monde/2013/12/19/un-millier-de-morts-en-centrafrique-depuis-debut-decembre_967665?xtor=rss-450";
		String texte = article.getcontent(lien);
		String gb =NomsPropres.parcourirArticle(texte);
		System.out.println(gb);
		
	
	}

}
