package model;

import java.util.*;

import HotTopic.Mots;

/**
 * NomsPropres est la classe repr�sentant la liste des noms propres
 * r�cup�r�s dans les articles.
 * 
 * @author Im�ne & L�na
 * @version 6.5
 */
public class NomsPropres {

	
	/**
	 * Retourne le mot d�nu� de sa ponctuation et pr� trait�.
	 * 
	 * @param mot
	 * @return mot : le mot pr�-trait�
	 */
	public static String pretraitement(String mot){
		
		mot = mot.replaceAll("\\p{Punct}|\\d", " ");
		mot = mot.replace("�", "");
		
		/*if (mot.charAt(mot.length())=='_') {
			mot = mot.replace("_", "");
		}*/
		
		//@Deprecated 
		@SuppressWarnings("unused")
		String lien = "http://fr.wikipedia.org/wiki/" + mot; // traiter les mots compos�s pour afficher des underscore. Sp�cial:Recherche
		//to do : mettre ce lien hypertexte lorsqu'on clique sur le mot ActionEvent
		
		
		return mot;
	}
	
	
	/**
	 * Constructeur par d�faut
	 */
	public NomsPropres() {	 
	}
	
	
	/**
	 * Retourne la liste des noms propres de l'Article
	 * 
	 * @param texte
	 * @return NP : Noms Propres du texte en String NP
	 */
	public static String parcourirArticle(String texte)
	{
		
		String NP="";
		String NPs_finaux="";
		try {
		//Pr�-traitement de l'article
		
		//version 6.4
		texte= texte.replaceAll("[0-9]","");
		texte= texte.replace("%","");
		texte = texte.replaceAll("� ", "");
		texte = texte.replace("-", " ");
		texte = texte.replace("'", " ");
		texte = texte.replace("(","");
		//texte = texte.replace("�", "");
		//texte = texte.replace("�", "");
		texte = texte.replace("		", "");
		texte = texte.replace("          ", " ");
		texte = texte.replace("   ", " ");
		texte = texte.replace("  "," ");
		
		
		// version 6.3
		/*texte= texte.replaceAll("[0-9]","");
		texte= texte.replace("%","");
		texte = texte.replaceAll("  ", "");
		texte = texte.replaceAll("� ", "");*/
		//System.out.println(texte);
		
		// Scinde la phrase d�limit�e par .?!
		StringTokenizer phrase = new StringTokenizer(texte, ".?!");
		
		// Stockage des noms propres dans un StringBuffer de taille modulable
		StringBuffer nomsPropres = new StringBuffer();
		
		// Compteur de mots pour avoir le nombre de cases de tab
		int cpt = phrase.countTokens();
		//System.out.println("compteur :" + cpt);
		
		// Tableau � double entr�e tab[phrase][mots de la phrase]
		String[] tab[] = new String[cpt][200];
		
		// Parcours de la table
		for (int i=0;i< cpt; i++) 
		{
			// Stockage des mots s�par�s par des espaces
			String[] bout = phrase.nextToken().split("\\s");
			//System.out.println("nouvelle phrase:");
			
			for (int p = 0; p<bout.length;p++ )
			{
				tab[i][p]= bout[p] ;//enregistrons les morceaux de phrase.
				tab[i][p]= tab[i][p].replace("�", ""); // gestion des guillements dans le texte
				//System.out.println("mot:"+ tab[i][p]);
			}
			
			// Initialisation du tableau
			for (int p = bout.length; p<200; p++) {
				tab[i][p]="";
			}
		}
		
		
		 
		// Detector of NP
		for(int j=0;j<tab.length-1;j++)
		{
			//System.out.println("yop0");
			if (tab[j].length>3) 
			{
				//try {
						for (int i=2; i<tab[j].length-1 ; i++)
					     {
					    	 //System.out.println(tab[j][i]);
							@SuppressWarnings("unused")
							int it =0;
							
							// Si un premier mot a une majuscule en 1ere lettre ET n'est pas un nombre ET la phrase ne commence pas par un espace
							if (tab[j][i].length()>0 &&tab[j][i].charAt(0)== Character.toUpperCase(tab[j][i].charAt(0)) && isANumber(tab[j][i]) == false && tab[j][i].charAt(0)!=' ')
					    	 {
								//System.out.println("rep�rage NP");
								// Tant qu'il y a des noms propres successifs
								while (tab[j][i].length()>0 &&tab[j][i].charAt(0)== Character.toUpperCase(tab[j][i].charAt(0)) && isANumber(tab[j][i]) == false && tab[j][i].charAt(0)!=' ')
								{
									it+=1;
									//System.out.println("yop2");
									nomsPropres = nomsPropres.append(pretraitement(tab[j][i])+"_");
									i++;
								}
								
								nomsPropres = nomsPropres.append(" "); 
								//System.out.println(" NP");
					    	 }	
							//System.out.println("fin d'une it�ration");
					      }     
			}
			
			 else //catch (IndexOutOfBoundsException e)
				{
					System.out.println("pb de taille");
				}
			
		}
		NP = nomsPropres.toString();
		NP = NP.replace(" _", " ");
		NP = NP.replace("_ ", " ");
		//System.out.println(nomsPropres); 
		
		List<String> tab_NP = new ArrayList<String>();
		List<String> tab_NP_sans = new ArrayList<String>();
		NomsPropres.separerNomsPropres(NP, tab_NP);
		tab_NP_sans = NomsPropres.supprimerDoublon(tab_NP);
		NPs_finaux = NomsPropres.getContentNomsPropres(tab_NP_sans);
		}
		catch (Exception e) {
			System.out.println("Erreur: R�cup�ration des noms propres - "+ e);
			e.printStackTrace();
		}
		return NPs_finaux;

	}
	
	/**
	 * Retourne un boolean si le mot est un nombre.
	 * 
	 * @param s : teste sur un string pass� en param�tre.
	 * @return boolean 
	 */
	 static boolean isANumber(String s) {
  	  if (s == null) return false;
  	  try {
  	    new java.math.BigDecimal(s);
  	    return true;
  	  } catch (NumberFormatException e) {
  	    return false;
  	  }
  	}
	/**
	 * S�pare et distingue chaque nom propre du String ligne_NP en les stockant dans une liste.
	 * @param ligne_NP : Chaine de noms propres.
	 * @param tab_NP : liste de noms propres.
	 */
	 public static void separerNomsPropres(String ligne_NP, List<String> tab_NP) {
		int car = 0;
		    
		int n = ligne_NP.length();
		boolean espace = true;
		int j;
		    
		//M�thode manuelle de r�cup�ration des noms propres : //" Les forces de l'ex-S�l�ka(test de 10% Fran�ais) et Fran�ais "
		while (car<n) {
		    j = 0;
		    String nouveau = "";
		    while (ligne_NP.charAt(car+j) != ' ' || car == n) {
		    	espace = false;
		    	nouveau = nouveau + ligne_NP.charAt(car+j);
		    	j++;
		    }
		    if (espace == false) {
		    	espace = true;
		    	tab_NP.add(nouveau);
		    	car = car + j;
		    	j = 0;
		    }
		    else {
		    	j++;;
		    }
		    car = car + j;
		   }
	 }
	 /**
	  * Supprime les doublons de noms propres dans la liste de Noms Propres
	  * @param tab_NP
	  * @return tab_NP_sans
	  */
	 public static List<String> supprimerDoublon(List<String> tab_NP) {
		List<String> tab_NP_sans = new ArrayList<String>();
		for (int i=0; i<tab_NP.size(); i++) {
			String NP_courant = (String) tab_NP.get(i);
			boolean doublon = false;
			for (int j=i+1; j<tab_NP.size(); j++) {
				String NP_comparaison = (String) tab_NP.get(j);
				if (NP_courant.equals(NP_comparaison) == true && NP_comparaison != " ") {
					doublon = true;
					NP_comparaison = " ";//on remplace le doublon par un espace
				}
			}
			if (doublon == false) {
				tab_NP_sans.add(NP_courant);
			}
		}
		return tab_NP_sans;
	}
	 /**
	  * Stocke les Noms Propres de la liste dans un StringBuffer de longueur qui s'adapte au nombre de Noms Propres.
	  * @param tab_NP : Une liste de Noms Propres
	  * @return content_NP : Un StringBuffer qui contient les noms propres d'un article.
	  */
	 public static String getContentNomsPropres(List<String> tab_NP) {
		 StringBuffer content_NP_buffer = new StringBuffer();
		 String content_NP = "";
		 for (int i=0; i<tab_NP.size(); i++) {
			 content_NP_buffer.append(tab_NP.get(i)+" ");
		 }
		 content_NP = content_NP_buffer.toString();
		 return content_NP;
	 }

}