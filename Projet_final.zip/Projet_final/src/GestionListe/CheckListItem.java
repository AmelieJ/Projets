package GestionListe;

/**
 * Classe utilis�e pour d�finir le nom de chaque journal et si celui-ci est s�lectionn� ou non. (Case coch�e ou non)
 *
 */
public class CheckListItem
{
	private String  label;
	private boolean isSelected = false;
 
	/**
	 * Constructeur initialisant le label � celui pass� en param�tre
	 * @param label un String
	 */
	public CheckListItem(String label)
	{
		this.label = label;
	}
 
	/**
	 * Retourne un bool�en correspondant � l'�tat de la case suivant qu'elle est s�lectionn�e.
	 * @return un bool�en
	 */
	public boolean isSelected()
	{
		return isSelected;
	}
 
	/**
	 * Met une case � l'�tat de s�lection pass� en param�tre.
	 * @param isSelected
	 */
	public void setSelected(boolean isSelected)
	{
		this.isSelected = isSelected;
	}
 
	/**
	 * Affiche le label en String
	 * @return le string label
	 */
	public String toString()
	{
		return label;
	}
}
