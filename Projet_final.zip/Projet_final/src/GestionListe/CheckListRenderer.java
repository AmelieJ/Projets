package GestionListe;

import java.awt.Component;

import javax.swing.JCheckBox;
import javax.swing.JList;
import javax.swing.ListCellRenderer;

/**
 * Cr�ation de la liste de journaux avec une case pour chaque journal.
 * 
 */
public class CheckListRenderer extends JCheckBox implements ListCellRenderer {
	
	/*
	 * (non-Javadoc)
	 * @see javax.swing.ListCellRenderer#getListCellRendererComponent(javax.swing.JList, java.lang.Object, int, boolean, boolean)
	 */
	/**
	 * 
	 * @param list : Une liste contenant les id de journaux s�lectionn�s
	 * @param value : Un objet 
	 * @param index : Un entier 
	 * @param isSelected : Un bool�en correspondant � l'�tat de s�lection de la case
	 * @param hasFocus : Un bool�en .
	 * 
	 */
	public Component getListCellRendererComponent(
			JList list, Object value, int index,
			boolean isSelected, boolean hasFocus)
	{
		setEnabled(list.isEnabled());
		setSelected(((CheckListItem)value).isSelected());
		setFont(list.getFont());
		setBackground(list.getBackground());
		setForeground(list.getForeground());
		setText(value.toString());
		return this;
	}
} 
