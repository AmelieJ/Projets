package Interface;


import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;

import javax.swing.JLabel;


/**
 * Il s'agit de la fen�tre principale du projet : fen�tre avec les diff�rents onglets. 
 * Onglets avec articles des journaux auxquels je suis abonn�,
 * onglet du journal personnalis�
 * onglet des articles lik�s
 * @author Maude
 *
 */
public class Fenetre_principale extends JFrame{

	/**
	 * Classe qui cr�e la fen�tre principale
	 */

	private JPanel panel_accueil;

	JLabel principalLabel = new JLabel("Fen�tre Principale ");
	JLabel profilLabel = new JLabel("Votre Profil");

	
	public static void main(String[] args) {
		/**
		 * Lancement de l'application
		 */
		
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					Fenetre_principale frame = new Fenetre_principale();
					frame.setVisible(true);
					frame.setLocationRelativeTo(null);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}


	/**
	 * Il s'agit du constructeur de la fen�tre principale
	 */
	public Fenetre_principale() {
		setTitle("GNEWS : toutes les news par les Ninjava");
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 700, 529);


		// ****************************** Page d'accueil
		// ***********************************************
		
		panel_accueil = new Panel_Accueil(this);
		getContentPane().add(panel_accueil);
		repaint();


	}

}
