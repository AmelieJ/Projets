package Interface;

import java.awt.Color;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.KeyAdapter;
import java.awt.event.KeyEvent;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JEditorPane;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JPasswordField;
import javax.swing.JTextField;
import javax.swing.JTextPane;
import javax.swing.UIManager;
import javax.swing.border.LineBorder;

/**
 * Il s'agit de l'interface de connexion. On rentre le login et de mot de passe
 * pour se connecter. On r�cup�re aussi l'id utilisateur pour effectuer des
 * actions comme afficher les articles auxquels l'utilisateur connect� est
 * abonn�
 * 
 * @author Maude
 * 
 */
public class Panel_Connexion extends JPanel {

	private JFrame f;
	private JButton bt_creer_compte;
	private JButton bt_conn;
	private JButton annuler;
	private JLabel icone_gnews;
	private JPanel panel_connexion;
	private JLabel mdp;
	private JLabel utilisateur;
	private JTextField login;
	private JPasswordField password;
	private static int id_user;
	private JLabel logo;

	// ************* On cr�er la fen�tre **************
	/**
	 * Cr�ation de la fen�tre de connexion
	 * @param fenetre : JFrame
	 */
	public Panel_Connexion(JFrame fenetre) {
		this.setBounds(0, 0, 700, 530);
		this.setBackground(Color.WHITE);
		this.setBorder(new LineBorder(new Color(0, 0, 0), 3, true));
		this.f = fenetre;

		// ************* On cr�er le bouton de cr�ation de compte *************
		bt_creer_compte = new JButton("Creer un compte");
		bt_creer_compte.setBounds(203, 406, 262, 23);
		bt_creer_compte.setBackground(UIManager.getColor("Button.background"));

		// ************* On ajoute un listener au bouton cr�er compte pour
		// pouvoir acc�der � un autre panel *************
		bt_creer_compte.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				f.getContentPane().removeAll(); // on "vide" le panel
				f.getContentPane().add(new Panel_CreerCompte(f)); // on remplit
																	// avec le
																	// nouveau
																	// panel
				f.repaint();
			}
		});
		this.setLayout(null);
		this.add(bt_creer_compte);

		// *************** On cr�er un JEditorPane : sous titre dans la fen�tre
		// **************
		JEditorPane sous_titre = new JEditorPane();
		sous_titre.setBounds(231, 209, 218, 20);
		sous_titre.setFont(new Font("Tahoma", Font.ITALIC, 11));
		sous_titre.setForeground(new Color(153, 153, 153));
		sous_titre.setEditable(false);
		sous_titre.setText("Connectez-vous pour acc\u00E9der \u00E0 vos news");
		this.add(sous_titre);

		// ************* On cr�er l'icone de la fen�tre ****************
		icone_gnews = new JLabel(new ImageIcon(Panel_Connexion.class.getResource("res/gnews.png")));
		icone_gnews.setBounds(203, 32, 207, 74);
		this.add(icone_gnews);

		// ************* On cr�er le panel de connexion ****************
		panel_connexion = new JPanel();
		panel_connexion.setBounds(181, 240, 295, 148);
		panel_connexion.setBorder(new LineBorder(new Color(0, 0, 0), 3, true));
		this.add(panel_connexion);
		panel_connexion.setLayout(null);

		// ************* On ajoute le champ mot de passe ******************
		mdp = new JLabel("Mot de passe:");
		mdp.setBounds(10, 61, 72, 16);
		panel_connexion.add(mdp);
		mdp.setFont(new Font("Nirmala UI", Font.PLAIN, 11));

		// ************* On ajoute le champ login **************************
		utilisateur = new JLabel("Login:");
		utilisateur.setBounds(10, 21, 33, 17);
		panel_connexion.add(utilisateur);
		utilisateur.setFont(new Font("Nirmala UI", Font.PLAIN, 12));

		// *********** On ajoute la zone de texte login ********************
		login = new JTextField();
		login.setBounds(92, 20, 118, 20);
		panel_connexion.add(login);
		login.setColumns(10);

		// ************* On ajoute la zone de texte mot de passe *************
		password = new JPasswordField();
		password.setBounds(92, 59, 122, 20);
		panel_connexion.add(password);

		// ************** On ajoute le bouton connexion ***********************
		bt_conn = new JButton("Connexion");
		bt_conn.setBackground(UIManager.getColor("Button.background"));
		bt_conn.setBounds(166, 114, 106, 23);
		panel_connexion.add(bt_conn);

		// ************** On ajoute un listener sur le bouton *****************
		bt_conn.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				id_user = testconnexion();

			}
		});

		// ************** On ajoute un bouton retour **************************
		annuler = new JButton("Annuler");
		annuler.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				f.getContentPane().removeAll();
				f.getContentPane().add(new Panel_Accueil(f));
			}
		});
		annuler.setBounds(203, 440, 262, 23);
		add(annuler);
		
		// ************** On cr�er un nouveau panel ****************************
		JTextPane touteLactuAvec = new JTextPane();
		touteLactuAvec.setBounds(145, 157, 366, 28);
		touteLactuAvec.setForeground(Color.GRAY);
		touteLactuAvec.setFont(new Font("Georgia", Font.BOLD, 20));
		touteLactuAvec.setText("Toute l'actu avec un seul compte");
		touteLactuAvec.setEditable(false);
		this.add(touteLactuAvec);

		password.addKeyListener(new KeyAdapter() {
			public void keyPressed(KeyEvent e) {
			if (e.getKeyCode() == KeyEvent.VK_ENTER) {
				id_user = testconnexion();
			}
		}
		});
		

	}

	/**
	 * Permet de se connecter a la base et de s'identifier avec un compte
	 * utilisateur et un mot de passe d�j� existant
	 * @return : un entier , l'identifiant de l'utilisateur
	 */
	public int testconnexion() {
		String nomBDD = "";
		String passwordBDD = "";
		char[] pass = password.getPassword();
		String passString = new String(pass);
		String pilote = "com.mysql.jdbc.Driver";
		int id = 0;
		try {

			Class.forName(pilote);

			Connection connexion = DriverManager.getConnection(
					"jdbc:mysql://localhost:3306/test", "root", "");
			//System.out.println("Connexion r�ussie!");

			Statement instruction = connexion.createStatement();

			ResultSet res2 = instruction
					.executeQuery("SELECT * FROM utilisateurs WHERE login='"
							+ login.getText() + "' && password='" + passString
							+ "'");

			while (res2.next()) {
				//if (e.getSource() == bt_conn) {
					nomBDD = res2.getString("login");
					passwordBDD = res2.getString("password");
					id = res2.getInt("ID");
				//}
			}
		} catch (ClassNotFoundException exc) {
			exc.printStackTrace();
		} catch (SQLException exc) {
			exc.printStackTrace();
		}

		if (login.getText().equals(nomBDD) && passString.equals(passwordBDD)) {
			f.getContentPane().removeAll();
			f.getContentPane().add(new Panel_Onglets(f, id));
			f.repaint();
			//System.out.println("id utilisateur: " + id);

		} else {
			JOptionPane.showMessageDialog(this,
					"Nom d'utilisateur/Mot de passe invalide", "Error Message",
					JOptionPane.ERROR_MESSAGE);
		}
		return id;
	}

	/**
	 * Getter de l'identifiant de l'utilisateur
	 * @return : un entier, l'identifiant de l'utilisateur
	 */
	public static int getid_user() {
		return id_user;
	}


}
