package Interface;

import java.awt.Color;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JEditorPane;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JProgressBar;
import javax.swing.JScrollPane;
import javax.swing.JTabbedPane;
import javax.swing.JTextPane;
import javax.swing.border.LineBorder;

/**
 * On cr�e la fen�tre qui s'affiche lorsqu'on se connecte en tant
 * qu'administrateur. L'administrateur aura la possiblit� de remplir et vider la
 * table contenant les articles. Il pourra �galement voir le profil de tous les
 * utilisateurs qui ont cr�� un compte sur cette application.
 * 
 * @author Am�lie
 * 
 */
public class Panel_admin extends JPanel {

	private JFrame fenetre;
	private static int id_user;
	private static JProgressBar progressBar;
	private static JScrollPane users = new JScrollPane();
	private static JTextPane les_users = new JTextPane();
	private static JEditorPane user[] = new JEditorPane[100];
	private static JButton btnRemplirLaBase;
	private static int id_courant[] = new int[100];

	/**
	 * Mise en place des diff�rents composants dans un panel qui sera affich�
	 * lors de la connexion de Bob.
	 * @param f : JFrame
	 * @param id : entier, identifiant de l'utilisateur
	 */
	public Panel_admin(JFrame f, int id) {
		this.fenetre = f;
		this.id_user = id;

		this.setBounds(0, 0, 700, 529);
		this.setBackground(Color.WHITE);
		this.setBorder(new LineBorder(new Color(0, 0, 0), 3, true));
		setLayout(null);

		JLabel img_gnews = new JLabel(new ImageIcon(Panel_admin.class.getResource("res/gnews.png")));
		img_gnews.setBounds(21, 24, 157, 61);
		this.add(img_gnews);

		JButton btnDconnexion = new JButton("D\u00E9connexion");
		btnDconnexion.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				fenetre.getContentPane().removeAll();
				fenetre.getContentPane().add(new Panel_Accueil(fenetre));
				fenetre.repaint();
			}
		});
		btnDconnexion.setBounds(527, 24, 124, 29);
		add(btnDconnexion);

		JTabbedPane Onglets = new JTabbedPane(JTabbedPane.TOP);
		Onglets.setBounds(21, 123, 652, 355);
		Onglets.setBackground(Color.WHITE);
		add(Onglets);

		JPanel bdd = new JPanel();
		bdd.setBackground(Color.WHITE);
		Onglets.addTab("Gestion Base de donn\u00E9es", null, bdd, null);
		Onglets.setBackgroundAt(0, Color.WHITE);
		bdd.setLayout(null);

		Thread t = new Thread(new Traitement());

		btnRemplirLaBase = new JButton("Collecter les articles");
		btnRemplirLaBase.addActionListener(new ActionChargement(t));
		btnRemplirLaBase.setBounds(24, 73, 211, 32);
		bdd.add(btnRemplirLaBase);

		JButton btnViderLaBase = new JButton("Supprimer tous les articles");
		btnViderLaBase.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				if (javax.swing.JOptionPane.showConfirmDialog(null,
						"Voulez vous vraiment vider la table", "Confirmation",
						javax.swing.JOptionPane.YES_NO_OPTION) == javax.swing.JOptionPane.YES_OPTION) {
					vider_table();
				}

			}
		});
		btnViderLaBase.setBounds(24, 208, 211, 32);
		bdd.add(btnViderLaBase);

		progressBar = new JProgressBar();
		progressBar.setBackground(new Color(173, 216, 230));
		progressBar.setFont(new Font("Georgia", Font.BOLD | Font.ITALIC, 11));
		progressBar.setBounds(265, 79, 249, 23);
		bdd.add(progressBar);
		progressBar.setStringPainted(true);

		JTextPane Attention1 = new JTextPane();
		Attention1.setEditable(false);
		Attention1.setForeground(new Color(176, 196, 222));
		Attention1.setFont(new Font("Tahoma", Font.ITALIC, 13));
		Attention1
				.setText("Cette op\u00E9ration peut prendre plusieurs minutes");
		Attention1.setBounds(263, 113, 288, 23);
		bdd.add(Attention1);

		JTextPane Attention2 = new JTextPane();
		Attention2.setForeground(new Color(250, 128, 114));
		Attention2.setFont(new Font("Tahoma", Font.ITALIC, 13));
		Attention2.setEditable(false);
		Attention2
				.setText("Attention, toute suppression sera d\u00E9finitive et vous devrez faire une nouvelle collecte pour avoir de nouveaux articles");
		Attention2.setBounds(245, 208, 368, 43);
		bdd.add(Attention2);
		
		Onglets.addTab("Profils des utilisateurs", null, users, null);
		Onglets.setEnabledAt(1, true);

		int y = 0;

		final JScrollPane scroll_user = new JScrollPane();
		users.setViewportView(scroll_user);

		les_users = new JTextPane();
		les_users.setEditable(false);
		scroll_user.setViewportView(les_users);

		y = AccesProfilsUtilisateurs();
		les_users.setPreferredSize(new Dimension(472, y));
		scroll_user.setViewportView(les_users);

		JTextPane Bienvenue = new JTextPane();
		Bienvenue.setBounds(256, 30, 169, 34);
		Bienvenue.setForeground(new Color(135, 206, 250));
		Bienvenue.setFont(new Font("Lucida Calligraphy", Font.BOLD, 20));
		Bienvenue.setEditable(false);
		Bienvenue.setText("Bonjour Bob!");
		add(Bienvenue);

		JTextPane soustitre = new JTextPane();
		soustitre.setBounds(188, 75, 352, 20);
		soustitre.setForeground(new Color(211, 211, 211));
		soustitre.setFont(new Font("Georgia", Font.BOLD | Font.ITALIC, 13));
		soustitre.setEditable(false);
		soustitre
				.setText("Vous \u00EAtes connect\u00E9 en tant qu'administrateur");
		add(soustitre);

	}

	/**
	 * M�thode pour vider la table des articles dans la base de donn�es.
	 */
	public void vider_table() {
		String pilote = "com.mysql.jdbc.Driver";
		try {
			Class.forName(pilote);

			Connection connexion = DriverManager.getConnection(
					"jdbc:mysql://localhost:3306/test", "root", "");
			System.out.println("Connexion r�ussie!");

			Statement instruction = connexion.createStatement();
			instruction.executeUpdate("TRUNCATE journal");
			
			ResultSet res = instruction.executeQuery("SELECT * FROM journal");
			int row = 0;
			
			while(res.next()){
				row=res.getRow();
			}
			if(row==0)
			{
				JOptionPane.showMessageDialog(this,
					"Base vid�e avec succ�s!!");
			}			
			

		} catch (ClassNotFoundException exc) {
			exc.printStackTrace();
		} catch (SQLException exc) {
			exc.printStackTrace();
		}
	}

	/**
	 * M�thode pour collecter les nouveaux articles et les stocker dans la base
	 * de donn�es.
	 */
	public static void remplir_table() {
		try {
			progressBar.setIndeterminate(true);
			progressBar.setString("T�l�chargement des articles");
			// Connexion au driver:
			Class.forName("com.mysql.jdbc.Driver").newInstance();
			java.sql.Connection conn;
			conn = java.sql.DriverManager.getConnection(
					"jdbc:mysql://localhost:3306/test", "root", "");
			//System.out.println("Connexion r�ussie  !!!");
			//System.out.println(" ");


			// R�cup�ration de flux
			ReadTest.flux("http://flux.20minutes.fr/c/32497/f/479493/index.rss", 1,"20 Minutes", conn); // 20minutes

			// ReadTest.flux("https://news.google.fr/news/feeds?pz=1&cf=all&ned=fr&hl=fr&output=rss",
			// "Google News",conn);
			ReadTest.flux("http://www.lequipe.fr/rss/actu_rss.xml?3431326.6002573073",
			2,"l'Equipe",conn); //equipe
			ReadTest.flux("http://www.humanite.fr/rss/actu.rss", 3, "Humanit�",
					conn); // humanit�
			ReadTest.flux("http://rss.lefigaro.fr/lefigaro/laune",4,"le Figaro",conn);
			// // figaro
			ReadTest.flux("http://rss.lemonde.fr/c/205/f/3050/index.rss", 5,
					"le Monde", conn); // monde
			ReadTest.flux("http://rss.feedsportal.com/c/499/f/413823/index.rss",6,"les Echos",conn);
			// // ecos
			ReadTest.flux("http://liberation.fr.feedsportal.com/c/32268/fe.ed/rss.liberation.fr/rss/9/",7,"Lib�ration",conn);
			// //liberation
			ReadTest.flux("http://rss.nytimes.com/services/xml/rss/nyt/HomePage.xml",8,"le New-York Times",conn);
			// //new york times
			ReadTest.flux("http://rue89.feedsportal.com/c/33822/f/608948/index.rss",9,"rue 89",conn); //rue 89

			HotTopic.TestGestionHotTopic.main(null);

		} // fin try
		catch (Exception e) {
			System.out.println("Erreur:" + e);
		}
	}

	/**
	 * Cette classe impl�mentant Runnable permet d'afficher la barre de
	 * chargement pendant que les articles sont collect�s.
	 * 
	 * @author Am�lie
	 *
	 */
	class Traitement implements Runnable {

		/**
		 * La m�thode run() est appel�e au lancement du thread. 
		 */
		@Override
		public void run() {
			// TODO Auto-generated method stub
			remplir_table();
			progressBar.setIndeterminate(false);
			progressBar.setString("T�l�chargement termin�");
		}

	}

	/**
	 * Cette m�thode permet de r�cup�rer la liste des utilisateurs depuis la base de donn�es et de les afficher.
	 * Au clic on affiche le profil de l'utilisateur.
	 * 
	 * @return entier,La taille de la zone de texte pour que la scrollbarre apparaisse correctement
	 */
	public static int AccesProfilsUtilisateurs() {
		int taille = 0;
		int i = 0;
		int x = 0;
		try {

			Class.forName("com.mysql.jdbc.Driver").newInstance();
			java.sql.Connection conn;
			conn = java.sql.DriverManager.getConnection(
					"jdbc:mysql://localhost:3306/test", "root", "");
			System.out.println("Connexion r�ussie  !!!");
			System.out.println(" ");

			String requete = "SELECT * FROM utilisateurs";
			PreparedStatement statement = conn.prepareStatement(requete);
			ResultSet result = statement.executeQuery();
			while (result.next()) {
				id_courant[i]= result.getInt("ID");
				String pseudo = result.getString("login");
				String password = result.getString("password");
				String res = "--------------------------------------------------------------------------------------------------";

				pseudo = "pseudo : " + pseudo;
				password = "password : " + password;

				user[i] = new JEditorPane();
				user[i].setEditable(false);
				user[i].setBounds(x, taille, 473, 80);

				user[i].setEditorKit(new javax.swing.text.html.HTMLEditorKit());

				user[i].setText(// "<img src="+ClassLoader.getSystemResource("flamme.gif").toString()+" width='20' height='30'>"
				"<font face='Tahoma' color='#FF6347' size='6'><b>" + id_courant[i]
						+ "</b></font><br/>"
						+ "<font face='Tahoma' size='5'><i>" + pseudo
						+ "</i></font><br/>"
						+ "<font face='Tahoma' size='4'><u>" + password
						+ "</font></u><br/>" + "<font face='Tahoma' size='4'>"
						+ res + "</font><br/>");

				les_users.add(user[i]);
				taille = taille + 80;
				i = i++;

				user[i].addMouseListener(new UserViewer(id_courant[i]));

			}
		} catch (Exception e) {
			e.printStackTrace();
			System.out.println("Erreur : Affichage des profils utilisateurs - "
					+ e);
		}
		return taille;
	}

	/**
	 * Cette classe est n�cessaire pour que chaque utilisateur soit cliquable pour afficher son profil.
	 * @author Am�lie
	 *
	 */
	public static class UserViewer extends MouseAdapter {
		int id_utilisateur;

		/**
		 * Constructeur de la classe
		 * @param iduser : entier, identifiant de l'utilisateur
		 */
		public UserViewer(int iduser) {
			super();
			this.id_utilisateur = iduser;
		}

		/**
		 * Getter de l'identifiant utilisateur
		 * @return : entier, identifiant de l'utilisateur
		 */
		public int getIduser() {
			return id_utilisateur;
		}

		/**
		 * Setter de l'identifiant utilisateur
		 * @param iduser : entier, identifiant de l'utilisateur
		 */
		public void setIduser(int iduser) {
			this.id_utilisateur = iduser;
		}

		/**
		 * M�thode lorsque l'on clique sur l'onglet on acc�de aux diff�rents profils des utilisateurs
		 */
		public void mouseClicked(MouseEvent arg0) {

			Profil_user p  = new Profil_user(id_utilisateur);
			p.setVisible(true);

		}
	}
	
	/**
	 * On fait la r�cup�ration des donn�es concernant le profil de l'utilisateur
	 * @author Maude
	 *
	 */
	public class ActionChargement implements ActionListener{
		Thread thread;
		/**
		 * Constructeur de la m�thode
		 * @param t
		 */
		public ActionChargement(Thread t){
			this.thread = t;
		}
	
	public void actionPerformed(ActionEvent e) {
		
			thread.start();
		
				
	}	
	}
}
