package Interface;

import java.awt.Color;
import java.awt.Dimension;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.io.IOException;
import java.io.InputStream;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import javax.imageio.ImageIO;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JEditorPane;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTextArea;
import javax.swing.JTextPane;
import javax.swing.border.LineBorder;

/**
 * Ici, on cr�er la fen�tre d'accueil : celle qui s'affiche au lancement de
 * l'application avec les articles qui s'affichent, les boutons de connexion
 * etc.
 * 
 * @author Maude
 * 
 */
public class Panel_Accueil extends JPanel {

	private static JEditorPane article []= new JEditorPane[100];
	
	private JLabel principalLabel = new JLabel("Fen�tre Principale ");
	private JLabel profilLabel = new JLabel("Votre Profil");
	private static JTextPane les_articles = new JTextPane();
	
	private int id_user;
	private static int idj = 0;
	private static int i=0;
	private static int id_journal_lu[] = new int[100];
	private JFrame fenetre;

	
	/**
	 * Constructeur du panel d'accueil
	 * @param f : JFrame
	 */
	public Panel_Accueil(JFrame f) {

		this.fenetre = f;

		this.setBounds(0, 0, 700, 529);
		this.setBackground(Color.WHITE);
		fenetre.getContentPane().add(this);
		this.setBorder(new LineBorder(new Color(0, 0, 0), 3, true));
		this.setLayout(null);

		// ************** On ajoute le bouton connexion
		// **************************
		JButton btnConnexion = new JButton("Connexion");
		btnConnexion.setBounds(523, 11, 138, 23);
		btnConnexion.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				fenetre.getContentPane().removeAll();
				fenetre.getContentPane().add(new Panel_Connexion(fenetre));
				fenetre.repaint();
			}
		});

		// *************** On ajoute l'image
		// Gnews************************************
		JLabel img_gnews = new JLabel(new ImageIcon(Panel_Accueil.class.getResource("res/gnews.png")));
		img_gnews.setBounds(10, 11, 174, 54);

		JButton btnCreerUnCompte = new JButton("Creer un compte");
		btnCreerUnCompte.setBounds(523, 45, 138, 23);
		btnCreerUnCompte.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				fenetre.getContentPane().removeAll();
				fenetre.getContentPane().add(new Panel_CreerCompte(fenetre));
				fenetre.repaint();
			}
		});

		this.add(img_gnews);
		this.add(btnCreerUnCompte);
		this.add(btnConnexion);
		this.add(img_gnews);

		// ************** On ajoute le scrollPane ***********************
		JScrollPane pane_accueil = new JScrollPane();
		pane_accueil.setBounds(30, 76, 631, 401);
		this.add(pane_accueil);
		
		JScrollPane scrollPane = new JScrollPane();
		scrollPane.setBounds(30, 76, 589, 387);
		pane_accueil.setViewportView(scrollPane);

		// *************** Zone de texte o� tous les articles sont affich�s
		// ***************
		JTextArea tous_articles = new JTextArea();
		tous_articles.setBounds(30, 76, 589, 387);
		tous_articles.setWrapStyleWord(true);
		tous_articles.setLineWrap(true);
		tous_articles.setEditable(false);
		scrollPane.setViewportView(tous_articles);

		// *************** Connexion � la base pour afficher tous les articles
		// **************
		
		les_articles = new JTextPane();
		les_articles.setEditable(false);
		scrollPane.setViewportView(les_articles);
		
		int x=0;
		int y=0;
		
		try {
			String pilote = "com.mysql.jdbc.Driver";
			Class.forName(pilote);

			Connection connexion = DriverManager.getConnection(
					"jdbc:mysql://localhost:3306/test", "root", "");
			System.out.println("Connexion r�ussie!");
			Statement instruction = connexion.createStatement();
			ResultSet resultat = instruction
					.executeQuery("SELECT * FROM journal");

			while (resultat.next()) {

				article[i] = new JEditorPane();
				article[i].setEditable(false);
				article[i].setBounds(x, y, 500, 120);
				article[i].setEditorKit(new javax.swing.text.html.HTMLEditorKit());
				
				id_journal_lu[i] = resultat.getInt("ID");						
				
				String titre_journal = resultat.getString("nom_journal");
				String titre_article = resultat.getString("Titre_article");
				String description_article = resultat.getString("Description");
				String res = "---------------------------------------------------------------------------" ;

				article[i].setText("<font face='Tahoma' color='gray' size='5'><b>"+titre_journal+"</b></font><br/>"+
						//"<font face='Tahoma' size='3'><i>"+date_article + "</i></font><br/>" +
						"<font face='Tahoma' size='4'><u>"+titre_article+"</font></u><br/>"+ 
						"<font face='Tahoma' size='4'>"+description_article + "</font><br/>"+
						"<font face='Tahoma' size='4'>"+res+"</font><br/>");
					
					les_articles.add(article[i]);
					y=y+120;
					
					
					idj=id_journal_lu[i];

					article[i].addMouseListener(new ArticleViewer(idj,id_user));
					i=i++;

			}
		} catch (ClassNotFoundException exc) {
			exc.printStackTrace();
		} catch (SQLException exc) {
			exc.printStackTrace();
		}
		
		les_articles.setPreferredSize(new Dimension(472,y));
		les_articles.setLayout(null);
		scrollPane.setViewportView(les_articles);

	}
	
	/**
	 * La classe Article Viewer nous permet d'afficher l'article complet lorsqu'on clique dessus dans la liste des articles
	 * @author Am�lie
	 *
	 */	
	class ArticleViewer extends MouseAdapter{
		
		int numArticle;
		int iduser = 0;
		
		/**
		 * Constructeur de la classe
		 * @param numArticle : entier, num�ro d'article
		 * @param iduser : entier, identifiant de l'utilisateur
		 */
		public ArticleViewer(int numArticle, int iduser) {
			super();
			this.numArticle = numArticle;
			this.iduser = iduser;
		}

		/**
		 * M�thode pour r�cup�rer le num�ro de l'article
		 * @return un entier : le num�ro de l'article
		 */
		public int getNumArticle() {
			return numArticle;
		}

		/**
		 * Setter du num�ro de l'article
		 * @param numArticle : entier, num�ro de l'article
		 */
		public void setNumArticle(int numArticle) {
			this.numArticle = numArticle;
		}

		/**
		 * Getter de l'identifiant utilisateur
		 * @return un entier : l'identifiant de l'utilisateur
		 */
		public int getIduser() {
			return iduser;
		}

		/**
		 * Setter de l'identifiant de l'utilisateur
		 * @param iduser entier : identifiant de l'utilisateur
		 */
		public void setIduser(int iduser) {
			this.iduser = iduser;
		}

		/**
		 * Quand on clique on g�n�re une nouvelle fen�tre d'article complet
		 */
		public void mouseClicked(MouseEvent arg0) {
			
			Article_Complet a  = new Article_Complet(numArticle,id_user);
			a.setVisible(true);
			
		}
	}

}
