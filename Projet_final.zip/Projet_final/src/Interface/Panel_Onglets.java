package Interface;
import GestionListe.CheckListItem;
import GestionListe.CheckListRenderer;
import HotTopic.GestionHotTopic;
import HotTopic.GestionJournalPerso;
import HotTopic.Mots;
import HotTopic.MotsLikes;

import java.awt.Color;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JList;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTabbedPane;
import javax.swing.JTextPane;
import javax.swing.ListSelectionModel;
import javax.swing.border.LineBorder;
import javax.swing.event.ChangeEvent;
import javax.swing.event.ChangeListener;
import javax.swing.JEditorPane;

/**
 * On cr�er la fen�tre avec les onglets
 * @author Maude
 *
 */
public class Panel_Onglets extends JPanel {
	/**
	 * On cr�e la fen�tre avec les onglets
	 */

	private static JScrollPane onglet_journal_perso = new JScrollPane();
	private JScrollPane onglet_like = new JScrollPane();
	static JScrollPane onglet_article = new JScrollPane();
	private JScrollPane onglet_hotTopic = new JScrollPane();
	private static JEditorPane article []= new JEditorPane[100];
	private static JEditorPane article_HT [] = new JEditorPane [100];
	private static JEditorPane article_like [] = new JEditorPane [100];
	
	private JLabel principalLabel = new JLabel("Fen�tre Principale ");
	private static JTextPane les_articles = new JTextPane();
	private static JTextPane les_articles_like = new JTextPane();
	private static JTextPane les_articles_jour2 = new JTextPane();
	
	private JFrame fenetre;
	private static int id_user;
	private static int idj = 0;
	private static int i=0;
	private static int id_journal_lu[] = new int[100];
	private static int id_article_like[] = new int[100];
	private static int id_article_j_perso[] = new int[100];
	
	private static Article_Complet [] a = new Article_Complet[100];
	
	private static CheckListItem item;
	private static JTextPane texte_HT = new JTextPane();
	private static JScrollPane gros_titre = new JScrollPane();
	
	private static JEditorPane art_journal_perso[] = new JEditorPane[10];
	
	private static int y;
	
	
	public Panel_Onglets(JFrame f, int id) {
		/**
		 * On cr�er le panel
		 */
		
		this.fenetre=f;
		this.id_user=id;

		this.setBounds(0, 0, 700, 529);
		this.setBackground(Color.WHITE);
		this.setBorder(new LineBorder(new Color(0, 0, 0), 3, true));
		this.setLayout(null);
		
		if(id_user==1){
			fenetre.getContentPane().removeAll();
			fenetre.getContentPane().add(new Panel_admin(fenetre,1));
			fenetre.repaint();
			
		}
		else{

//***************** On ajoute les onglets ************************
		JTabbedPane Onglets = new JTabbedPane(JTabbedPane.TOP);
		Onglets.setBounds(10, 96, 653, 377);
		Onglets.setBackground(Color.WHITE);
		this.add(Onglets);
		
//****************** On ajoute l'icone Gnews **********************
		JLabel img_gnews = new JLabel(new ImageIcon(Panel_Onglets.class.getResource("res/gnews.png")));
		img_gnews.setBounds(21, 24, 157, 61);
		this.add(img_gnews);

//****************** On ajoute le bouton d�connexion******************
		JButton btnRetour = new JButton("D\u00E9connexion");
		btnRetour.setBounds(524, 24, 139, 27);
		//********** On met un listener au bouton d�connexion **********
		btnRetour.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				fenetre.getContentPane().removeAll();
				fenetre.getContentPane().add(new Panel_Accueil(fenetre));
				fenetre.repaint();
			}
		});
		this.add(btnRetour);

//**************** On ajoute le bouton pour voir son profil *************
		JButton btnMon_profil = new JButton("Mon profil");
		btnMon_profil.setBounds(524, 58, 139, 27);
		//************* On met un listener sur le bouton pour voir son profil ********
		btnMon_profil.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				Profil_user p  = new Profil_user(id_user);
				p.setVisible(true);
			}
		});
		this.add(btnMon_profil);
		
//**************** On ajoute le premier onglet ****************

		Onglets.addTab("Articles", null, onglet_article);
		Onglets.setEnabledAt(0, true);

		JList list_flux = new JList(new CheckListItem[] {
				new CheckListItem("20 minutes"), 
				new CheckListItem("Equipe"),
				new CheckListItem("Humanit�"), 
				new CheckListItem("Figaro"),
				new CheckListItem("le Monde"),
				new CheckListItem("les Echos"),
				new CheckListItem("Liberation"),
				new CheckListItem("le New-York Times"), 
				new CheckListItem("Rue 89") });
		list_flux.setValueIsAdjusting(true);

		list_flux.setFont(new Font("Segoe Print", Font.PLAIN, 12));
		list_flux.setBorder(new LineBorder(new Color(0, 0, 0), 2));
		onglet_article.setRowHeaderView(list_flux);

		list_flux.setCellRenderer(new CheckListRenderer());

		list_flux.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
		
		
		
//************** M�thode pour selectionner une checkbox **********************

		JScrollPane art_scroll = new JScrollPane();
		onglet_article.setViewportView(art_scroll);
		
		les_articles= new JTextPane();
		les_articles.setText("Cochez une case pour voir les articles ");
		les_articles.setPreferredSize(new Dimension(472,550));
		les_articles.setEditable(false);
		art_scroll.setViewportView(les_articles);

		y=afficherArticles_abonnement(id_user);
		
		
		list_flux.addMouseListener(new EcouteurCases(id_user));
		les_articles.setLayout(null);
		
		les_articles.setPreferredSize(new Dimension(472,y));
		
		art_scroll.setViewportView(les_articles);


		
//**************** Onglet Articles Like


		Onglets.addTab("Articles lik�s", null, onglet_like);
		Onglets.setEnabledAt(1, true);
		
		final JScrollPane art_scroll_like = new JScrollPane();
		onglet_like.setViewportView(art_scroll_like);
		
		les_articles_like = new JTextPane();
		les_articles_like.setEditable(false);
		art_scroll_like.setViewportView(les_articles_like);

		y = afficherArticle_like(id_user);
		les_articles_like.setPreferredSize(new Dimension(472,y));
		art_scroll_like.setViewportView(les_articles_like);
		



		//***************** On ajoute les autres onglets ************************
				
		List<MotsLikes> mots_cles = new ArrayList<MotsLikes>();
		try {			
			String pilote = "com.mysql.jdbc.Driver";
			Class.forName(pilote);

			Connection connexion = DriverManager.getConnection(
					"jdbc:mysql://localhost:3306/test", "root", "");
			
			GestionJournalPerso.recuperationMotsLikesBase(connexion,mots_cles, id);
			
		}catch (Exception e) {
			e.printStackTrace();
		}

		Onglets.addTab("Journal Perso", null, onglet_journal_perso);
		Onglets.setEnabledAt(2, true);
		
		JScrollPane scrol_j_perso = new JScrollPane();
		onglet_journal_perso.setViewportView(scrol_j_perso);
			
		les_articles_jour2 = new JTextPane();
		les_articles_jour2.setEditable(false);
		gros_titre.setViewportView(les_articles_jour2);

		try {

			y=afficherJournalPerso(mots_cles,id_user);
		} catch (Exception e1) {
			System.out.println("Erreur: "+e1);
			e1.printStackTrace();
		}
	
		System.out.println("y j perso" + y);
		
		les_articles_jour2.setPreferredSize(new Dimension(472,y));
		scrol_j_perso.setViewportView(les_articles_jour2);
				
		
// ****************** Onglet HotTopic ***************************
		Onglets.addTab("Hot Topic",null, onglet_hotTopic);
		Onglets.setEnabledAt(3, true);
		
		JScrollPane scrollPane_HT = new JScrollPane();
		onglet_hotTopic.setViewportView(scrollPane_HT);
		
		texte_HT = new JTextPane();
		texte_HT.setEditable(false);
		scrollPane_HT.setViewportView(texte_HT);
		
		y= afficherHT(10);
		
		
		texte_HT.setPreferredSize(new Dimension(472,y));
		texte_HT.setLayout(null);
		scrollPane_HT.setViewportView(texte_HT);
		
		JEditorPane bienvenue = new JEditorPane();
		bienvenue.setForeground(new Color(135, 206, 250));
		bienvenue.setFont(new Font("Lucida Calligraphy", Font.BOLD, 20));
		bienvenue.setEditable(false);
		bienvenue.setBounds(241, 33, 234, 41);
		add(bienvenue);
		String nom="";
		
		try {
			
			String pilote = "com.mysql.jdbc.Driver";
			Class.forName(pilote);

			Connection connexion = DriverManager.getConnection(
					"jdbc:mysql://localhost:3306/test", "root", "");
			Statement statement = connexion.createStatement();
			ResultSet result = statement.executeQuery("SELECT login FROM utilisateurs WHERE ID = '"+id+"'");
			while(result.next()){
				nom = result.getString("login");
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		bienvenue.setText("Bienvenue "+nom);
			
		
		 ChangeListener changeListener = new ChangeListener() {
			 
             public void stateChanged(ChangeEvent changeEvent) {
               JTabbedPane sourceTabbedPane = (JTabbedPane) changeEvent.getSource();
               int index = sourceTabbedPane.getSelectedIndex();
               if(sourceTabbedPane.getTitleAt(index).equals("Articles lik�s")){
            	   y = afficherArticle_like(id_user);
					les_articles_like.setPreferredSize(new Dimension(472,y));
					art_scroll_like.setViewportView(les_articles_like);
               }
               if(sourceTabbedPane.getTitleAt(index).equals("Journal Perso")){
            	  //System.out.println("Journal Perso s�l�ctionn�");
               }
               
             }
           };
         Onglets.addChangeListener(changeListener);
		}
		
	}
	
public static int sAbonnerFlux(int id_user) {
	/** 
	 * M�thode pour s'abonner aux journaux
	 */
	int id_journal = 0;
	try {
		
		String pilote = "com.mysql.jdbc.Driver";
		Class.forName(pilote);

		Connection connexion = DriverManager.getConnection(
				"jdbc:mysql://localhost:3306/test", "root", "");
		System.out.println("Connexion r�ussie!");
		
		// on cherche la ligne correspondant a l utilisateur:
		
		String requete = "SELECT * FROM utilisateurs WHERE ID = ?";
		PreparedStatement statement = connexion.prepareStatement(requete,
				ResultSet.TYPE_SCROLL_INSENSITIVE,
				ResultSet.CONCUR_UPDATABLE); // permet la modif des donnees
		statement.setInt(1, id_user);
		ResultSet result = statement.executeQuery();

		String nomj = item.toString();
		String requete3 = "SELECT * FROM listejournaux WHERE nom = ?";
		PreparedStatement statement2 = connexion.prepareStatement(requete3,
				ResultSet.TYPE_SCROLL_INSENSITIVE,
				ResultSet.CONCUR_UPDATABLE);  // on r�cup�re le num du journal s�l�ctionn�
		statement2.setString(1, nomj);
	
		System.out.println(nomj);

		ResultSet res_idjour = statement2.executeQuery();


		
		String journal ="";
		/*while (res_idjour.next()) {
			id_journal = res_idjour.getInt("ID");
			journal = res_idjour.getString("nom");
			}*/
		
		String abonnement = "";
		String nouveau = "";
		int tab[] = new int[9]; // tableau contenant les valeurs
								// d'abonnement

		while (result.next()) {
			abonnement = result.getString("abonnement");
			for (int i = 0; i < 9; i++) {
				tab[i] = abonnement.charAt(i) - 48; // Correspondance du chiffre � leur table ASCII
			}
		}
		
		//System.out.println("abonnement : " +abonnement);

		//System.out.println(result);
		//System.out.println(res_idjour);
		
		while (res_idjour.next()){
			id_journal=res_idjour.getInt("ID");
			if ( id_journal> 0 && id_journal < 10) {
				int i = 0;
				System.out.println("nouveau: "+journal);
				while (i < 9 && tab[i] != id_journal && tab[i] != 0) {
					nouveau = nouveau + abonnement.charAt(i);
					i = i + 1; // se place correctement
					System.out.println("nouveau: "+ nouveau);
				}
				if (tab[i] == 0) {
					nouveau = nouveau + id_journal;
					for (int j = i + 1; j < 9; j++) {
						nouveau = nouveau + "0";
					}
					System.out.println("nouveau: " + nouveau);
					result.first();
					result.updateString(4, nouveau);
					result.updateRow(); // valide les modifs

					System.out.println("abonnement r�ussi !");
					

				}
			}
							
		}
		
	} catch (Exception e) {
		System.out.println("Erreur abonnement");
		e.printStackTrace();
	}
	return id_user;
}

public static int afficherArticles_abonnement(int idu) {

	les_articles.repaint();
	int id_u=idu;

	int j=0;
	int x=0;
	y = 0;
	try {

		String pilote = "com.mysql.jdbc.Driver";
		Class.forName(pilote);

		Connection connexion = DriverManager.getConnection(
				"jdbc:mysql://localhost:3306/test", "root", "");
		Statement statement = connexion.createStatement();
		
		// recupere la liste d'abonnement de l'utilisateur 
		ResultSet result = statement.executeQuery("SELECT abonnement FROM utilisateurs WHERE ID = '"+id_u+"'");
		String abonnement ="";
		int tab[] = new int[9];  // tableau contenant les valeurs d'abonnement
		
		ResultSet result2=null;
		
		while (result.next()) {
			abonnement = result.getString("abonnement");
			
		}
		for (int k=0;k<9;k++) {
			tab[k]=abonnement.charAt(k)-48;
		}
			
		

			// recupere uniquement les journaux auxquels l'utilisateur est abonn�:


			String requete2 = "SELECT * FROM journal WHERE id_journal = ? OR id_journal = ? OR id_journal = ? OR id_journal = ? OR id_journal = ? OR id_journal = ? OR id_journal = ? OR id_journal = ? OR id_journal = ?  ";
			PreparedStatement statement2 = connexion.prepareStatement(requete2);
			statement2.setInt(1, tab[0]);
			statement2.setInt(2, tab[1]);
			statement2.setInt(3, tab[2]);
			statement2.setInt(4, tab[3]);
			statement2.setInt(5, tab[4]);
			statement2.setInt(6, tab[5]);
			statement2.setInt(7, tab[6]);
			statement2.setInt(8, tab[7]);
			statement2.setInt(9, tab[8]);
			result2 = statement2.executeQuery();
			
			//result2 = statement2.executeQuery("SELECT * FROM journal WHERE id_journal = '"+tab[k]+"'");
			
			//+
				while(result2.next()){
					
				article[j] = new JEditorPane();
				article[j].setEditable(false);
				article[j].setBounds(x, y, 473, 120);
				
				article[j].setEditorKit(new javax.swing.text.html.HTMLEditorKit());
				
				id_journal_lu[i] = result2.getInt("ID");						

				String titre_journal = result2.getString("nom_journal");
				String date_article = result2.getString("Date");
				String titre_article = result2.getString("Titre_article");
				String description_article = result2.getString("Description");
				String res = "--------------------------------------------------------------------------------------------------" ;
				
				article[j].setText(//"<img src="+ClassLoader.getSystemResource("flamme.gif").toString()+" width='20' height='30'>"
						 "<font face='Tahoma' color='#FF6347' size='6'><b>"+titre_journal+"</b></font><br/>"+
				"<font face='Tahoma' size='3'><i>"+date_article + "</i></font><br/>" +
				"<font face='Tahoma' size='4'><u>"+titre_article+"</font></u><br/>"+ 
				"<font face='Tahoma' size='4'>"+description_article + "</font><br/>"+
				"<font face='Tahoma' size='4'>"+res+"</font><br/>");
				
				
					les_articles.add(article[j]);

					y=y+120;
					j=j++;
					article[j].addMouseListener(new ArticleViewer(id_journal_lu[i],id_user));
			}
				i++;
				
				


	} catch (Exception e) {
		System.out.println("Erreur affichage abonnement");
		e.printStackTrace();
	}
	les_articles.setPreferredSize(new Dimension(472,y));
	return y;
	
}

public static class EcouteurCases extends MouseAdapter{

	int iduser;
	
	public EcouteurCases(int iduser) {
		super();
		this.iduser = iduser;
	}

	public int getIduser() {
		return iduser;
	}

	public void setIduser(int iduser) {
		this.iduser = iduser;
	}

	public void mouseClicked(MouseEvent event) {
		
		y=0;
		les_articles.repaint();
		JList list_flux = (JList) event.getSource();
		int index = list_flux.locationToIndex(event.getPoint());
		item = (CheckListItem) list_flux.getModel().getElementAt(index);
		item.setSelected(!item.isSelected());
		list_flux.repaint(list_flux.getCellBounds(index, index));
		
		/* Abonnement au flux & affichage des articles */

		y= afficherArticles_abonnement(sAbonnerFlux(id_user));
			
		les_articles.setPreferredSize(new Dimension(472,y));

	}
	
}

public static class ArticleViewer extends MouseAdapter{
	
	int numArticle;
	int iduser;
	
	public ArticleViewer(int numArticle, int iduser) {
		super();
		this.numArticle = numArticle;
		this.iduser = iduser;
	}

	public int getNumArticle() {
		return numArticle;
	}

	public void setNumArticle(int numArticle) {
		this.numArticle = numArticle;
	}


	public int getIduser() {
		return iduser;
	}

	public void setIduser(int iduser) {
		this.iduser = iduser;
	}

	public void mouseClicked(MouseEvent arg0) {
		
		Article_Complet a  = new Article_Complet(numArticle,id_user);
		a.setVisible(true);
		
	}
}

public static int afficherHT(int parametre){
	/**
	 * On affiche les hot topic
	 */
	int x=0;
	y=0;
	try{
		for (int j=parametre; j>0; j--) {
			Connection conn = DriverManager.getConnection(
					"jdbc:mysql://localhost:3306/test", "root", "");
			String requete2 = "SELECT * FROM journal WHERE HotTopic = ? ";
			PreparedStatement statement2 = conn.prepareStatement(requete2);
			statement2.setInt(1, j);
			ResultSet result2 = statement2.executeQuery();
			if (result2.first()) { // teste si il y a des articles pour ce mot-cl�
				result2.beforeFirst(); // on revient au premier article
				int cpt=0;
				int[] tab_id_journal = new int[3];
				while(result2.next() && cpt<3) {
					// affichage de l'article:
					tab_id_journal[cpt] = result2.getInt("id_journal");
					int k = 0;
					while ((k<cpt && tab_id_journal[cpt] != tab_id_journal[k]) && cpt != 0) {
						k++;
					}
					if (cpt == 0 || k == cpt) {
						article_HT[i] = new JEditorPane();
						article_HT[i].setEditable(false);
						article_HT[i].setBounds(x, y, 600, 150);
						article_HT[i].setEditorKit(new javax.swing.text.html.HTMLEditorKit());
						
						id_journal_lu[i] = result2.getInt("ID");						
						
						String titre_journal = result2.getString("nom_journal");
						String date_article = result2.getString("Date");
						String titre_article = result2.getString("Titre_article");
						String description_article = result2.getString("Description");
						String res = "--------------------------------------------------------------------------------------------------" ;
						
						article_HT[i].setText(//"<img src="+ClassLoader.getSystemResource("flamme.gif").toString()+" width='20' height='30'>"
								 "<font face='Tahoma' color='#FF6347' size='6'><b>"+titre_journal+"</b></font><br/>"+
						"<font face='Tahoma' size='3'><i>"+date_article + "</i></font><br/>" +
						"<font face='Tahoma' size='4'><u>"+titre_article+"</font></u><br/>"+ 
						"<font face='Tahoma' size='4'>"+description_article + "</font><br/>"+
						"<font face='Tahoma' size='4'>"+res+"</font><br/>");
						
						texte_HT.add(article_HT[i]);
						y=y+150;
						idj = id_journal_lu[i];
						article_HT[i].addMouseListener(new ArticleViewer(idj,id_user));
						i=i++;
						cpt++;
					}
				}
				if (cpt != 3) {
					int reste = 3 - cpt;
					if (reste == 2) {
						result2.first();
					}
					else {
						result2.first();
						result2.next();
					}
					cpt = 0;
					while (result2.next() && cpt<reste) {
						article_HT[i] = new JEditorPane();
						article_HT[i].setEditable(false);
						article_HT[i].setBounds(x, y, 473, 120);
						article_HT[i].setEditorKit(new javax.swing.text.html.HTMLEditorKit());
						
						id_journal_lu[i] = result2.getInt("ID");						
						
						String titre_journal = result2.getString("nom_journal");
						String date_article = result2.getString("Date");
						String titre_article = result2.getString("Titre_article");
						String description_article = result2.getString("Description");
						String res = "--------------------------------------------------------------------------------------------------" ;
						
						
						article_HT[i].setText(//"<img src="+ClassLoader.getSystemResource("flamme.gif").toString()+" width='20' height='30'>"
								 "<font face='Tahoma' color='#FF6347' size='6'><b>"+titre_journal+"</b></font><br/>"+
						"<font face='Tahoma' size='3'><i>"+date_article + "</i></font><br/>" +
						"<font face='Tahoma' size='4'><u>"+titre_article+"</font></u><br/>"+ 
						"<font face='Tahoma' size='4'>"+description_article + "</font><br/>"+
						"<font face='Tahoma' size='4'>"+res+"</font><br/>");
						
						texte_HT.add(article_HT[i]);
						y=y+150;
						idj = id_journal_lu[i];
						final int m=i;
						article_HT[i].addMouseListener(new ArticleViewer(idj,id_user));
						i=i++;
						cpt++;
					}
				}
			}
		}
	}
	catch(SQLException e){ e.printStackTrace();}
	return y;
}

public static int afficherArticle_like(int idu){
	les_articles_like.repaint();
	int id_u=idu;
	int i=0;
	int j=0;
	int x=0;
	y =0;

	try {
		String pilote = "com.mysql.jdbc.Driver";
		Class.forName(pilote);

		Connection connexion = DriverManager.getConnection(
				"jdbc:mysql://localhost:3306/test", "root", "");
		//System.out.println("Connexion r�ussie!");
		Statement instruction = connexion.createStatement();
		Statement instruction2 = connexion.createStatement();
		ResultSet resultat = instruction
				.executeQuery("SELECT DISTINCT(id_journal) FROM likes WHERE id_utilisateur = '"+ id_u + "'");

		//ResultSet res_article =null;
		while (resultat.next()) {
			id_article_like[i] = resultat.getInt("id_journal");
		
			ResultSet res_article = instruction2
				.executeQuery("SELECT * FROM journal WHERE ID='"
						+ id_article_like[i] + "'");
			
			//System.out.println("id_article lik�" + id_article_like[i]);
			while (res_article.next()) {

			//afficherArticles(idarticle_like,id_u);
			
				article_like[j] = new JEditorPane();
				article_like[j].setEditable(false);
				article_like[j].setBounds(x, y, 473, 120);
				
				article_like[j].setEditorKit(new javax.swing.text.html.HTMLEditorKit());
				
				String titre_journal = res_article.getString("nom_journal");
				String date_article = res_article.getString("Date");
				String titre_article = res_article.getString("Titre_article");
				String description_article = res_article.getString("Description");
				String res = "--------------------------------------------------------------------------------------------------" ;
				
				
				article_like[j].setText(//"<img src="+ClassLoader.getSystemResource("flamme.gif").toString()+" width='20' height='30'>"
						 "<font face='Tahoma' color='#FF6347' size='6'><b>"+titre_journal+"</b></font><br/>"+
				"<font face='Tahoma' size='3'><i>"+date_article + "</i></font><br/>" +
				"<font face='Tahoma' size='4'><u>"+titre_article+"</font></u><br/>"+ 
				"<font face='Tahoma' size='4'>"+description_article + "</font><br/>"+
				"<font face='Tahoma' size='4'>"+res+"</font><br/>");
				
				les_articles_like.add(article_like[j]);
				y = y + 120;
				
				article_like[j].addMouseListener(new ArticleViewer(id_article_like[i],id_user));
				j =j++;
			}
			i++;
		}
	} catch (ClassNotFoundException exc) {
		exc.printStackTrace();
	} catch (SQLException exc) {
		exc.printStackTrace();
	}
	return y;
}

public static int afficherJournalPerso(List<MotsLikes> liste, int id_utilisateur) throws Exception{
	
	String pilote = "com.mysql.jdbc.Driver";
	int p=0;
	int x=0;
	y=0;
	int i=0;
	int id=0;
	List<Mots> mots_base = new ArrayList<Mots>();
	
	// connexion base
	Connection connexion;
	try {
		Class.forName(pilote);
	
		connexion = DriverManager.getConnection("jdbc:mysql://localhost:3306/test", "root", "");
	
		mots_base = GestionHotTopic.trierTitresBase(connexion);
		Mots dernier_mot = new Mots();
		mots_base.add(dernier_mot);
	
		int m = mots_base.size();
		int n = liste.size();
		int tab[] = new int[9];  // tableau contenant les valeurs d'abonnement
		int cpt_like = 0;
	
		// recupere la liste d'abonnement de l'utilisateur
		try {
			String requete = "SELECT abonnement FROM utilisateurs WHERE ID = ?";
			PreparedStatement statement = connexion.prepareStatement(requete); 
			statement.setInt(1, id_utilisateur);
			ResultSet result = statement.executeQuery();
			String abonnement ="";
		
			while (result.next()) {
				abonnement = result.getString("abonnement");
				for (int f=0; f<9; f++) {
					tab[f]=+abonnement.charAt(f)-48; // on convertit la liste des id_journaux 123.. en int 1, 2, 3
					//System.out.println(tab[f]);
				}
			}
		//System.out.println("juste avant");
		}catch (Exception e) {e.printStackTrace(); System.out.println("Erreur recuperation abonnement: "+e);}		
		//System.out.println("juste apres");	
		List<Integer> tab_id_abonnement = new ArrayList<Integer>();
		while (i<n && cpt_like<4) {
			MotsLikes mot_courant = liste.get(i); 
			String nom_courant = mot_courant.getMot();
			//System.out.println("mot_courant : "+ nom_courant);
			int j = 0;
			while (!nom_courant.equals(mots_base.get(j).getMot()) && j<m -1) {
				//Tant que le nom courant de notre liste de mots lik�s est diff�rent d'un mot de notre liste de titres
				j++;
			}
		
			if (j!=m) { //Si on a trouv� une similitude entre deux mots,
				List<Integer> tab_id = new ArrayList<Integer>();
		
				tab_id = mots_base.get(j).getContentTabId();//on r�cup�re la table des id du mot � la position j de la liste des mots de la base

				int k=0;
				int cpt=0;
				int affichage = tab_id.size();
				if (affichage - 2 > 0) {
					affichage = 2;
				}
				int bug=0;
				//System.out.println(affichage);
				while (k<tab_id.size() && cpt<affichage) {
					
					int id_courant = tab_id.get(k);
					int h=0;
					tab_id_abonnement.add(0);
				
					while (id_courant!=tab_id_abonnement.get(h) && h<tab_id_abonnement.size()-1) {
						h++;
					//System.out.println(h);
					}
					//System.out.println(h);
					if (h==tab_id_abonnement.size()-1 || bug==4) {  // si pas de doublon
					
						String titre_journal;
						String titre_article;
						String description_article;
					
						try {
							tab_id_abonnement.add(id_courant);
						
							// recupere uniquement les articles des journaux auxquels l'utilisateur est abonn�:
							String requete2 = "SELECT * FROM journal WHERE (id_journal = ? OR id_journal = ? OR id_journal = ? OR id_journal = ? OR id_journal = ? OR id_journal = ? OR id_journal = ? OR id_journal = ? OR id_journal = ?) AND ID = ? ";
							PreparedStatement statement2 = connexion.prepareStatement(requete2); 
							statement2.setInt(1, tab[0]);
							statement2.setInt(2, tab[1]);
							statement2.setInt(3, tab[2]);
							statement2.setInt(4, tab[3]);
							statement2.setInt(5, tab[4]);
							statement2.setInt(6, tab[5]);
							statement2.setInt(7, tab[6]);
							statement2.setInt(8, tab[7]);
							statement2.setInt(9, tab[8]);
							statement2.setInt(10,tab_id.get(k));
							ResultSet result2 = statement2.executeQuery();
							//System.out.println(tab_id.get(k));
							k++;
							//System.out.println(result2.next());
						
							while(result2.next() &&cpt<affichage){
							//System.out.println("kjd");
								if (cpt == 0) {
									cpt_like++;			
								}
							
								// affichage des infos de l'article:						
								titre_journal = result2.getString("nom_journal");
								titre_article = result2.getString("Titre_article");
								description_article = result2.getString("Description");
							
					
							
								art_journal_perso[p] = new JEditorPane();
								art_journal_perso[p].setEditable(false);
								art_journal_perso[p].setBounds(x, y, 473, 120);
								art_journal_perso[p].setEditorKit(new javax.swing.text.html.HTMLEditorKit());
							
								art_journal_perso[p].setText("<font face='Tahoma' color='#FF6347' size='5'><b>"+titre_journal+"</b></font><br/>"+
										"<font face='Tahoma' size='3'><u>"+titre_article+"</font></u><br/>"+ 
										"<font face='Tahoma' size='3'>"+description_article + "</font><br/>");
							
														
								les_articles_jour2.add(art_journal_perso[p]);
								y = y+120;
								
								cpt++;
								id_article_j_perso[id] = result2.getInt("ID");
								art_journal_perso[p].addMouseListener(new ArticleViewer(id_article_j_perso[id],id_user));	
								p++;
							}  //fin while
						}catch (Exception e2) {
							System.out.println("Erreur: "+e2);
							e2.printStackTrace();
						}
					}		// fin if
					else bug++;
			}	// fin while
			
		} 	// fin grand if
			//id++;
			i++;
	}	//fin grand while
	/*System.out.println(art_journal_perso[0].getText());
			System.out.println(art_journal_perso[1].getText());
			art1.setViewportView(art_journal_perso[0]);
			art2.setViewportView(art_journal_perso[1]);
			art3.setViewportView(art_journal_perso[2]);
			art4.setViewportView(art_journal_perso[3]);
			gros_titre.setViewportView(art_journal_perso[4]);
			art5.setViewportView(art_journal_perso[5]);
			art6.setViewportView(art_journal_perso[6]);*/
							
			//System.out.println("oui");
			//     A FAIRE !!!
			// pour chaque id on verifie dans la base si le bonhomme est abonn�
			// on met dans un nouveau tableau (� afficher avec l'interface)
			// nombre limit� � 3 ou autre pour chaque mot cl�

	onglet_journal_perso.repaint();
	
	}
	finally {}
	return y;
}
		
}
	






