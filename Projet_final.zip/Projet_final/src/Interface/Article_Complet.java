package Interface;

import java.awt.Color;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.net.MalformedURLException;
import java.net.URL;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import javax.swing.DefaultListModel;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JEditorPane;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTextPane;
import javax.swing.border.EmptyBorder;

import HotTopic.GestionJournalPerso;
import HotTopic.Mots;
import LancementNavigateur.BrowserControl;

/**
 * Cette classe g�n�re une fen�tre qui contient l'article complet avec : - la
 * liste des noms propre - l'article complet - un bouton retour - un bouton like
 * On a une m�thode pour "liker" les articles, un m�thode pour g�n�rer le lien
 * wikip�dia.
 * 
 * @author Maude
 * 
 */
public class Article_Complet extends JFrame {
	/**
	 * On cr�e une fen�tre qui contient l'article complet et la liste des noms propres cliquables
	 */
	private static final long serialVersionUID = 1L;
	private JPanel panel_principal;
	private static URL lien_wiki;
	private JButton pouce;
	private JButton pouce2;
	private  int id_journal;
	private int id_user;


	/**
	 * On cr�e la fen�tre, il s'agit du constructeur
	 * @param id_j : entier, identifiant du journal
	 * @param id_u : entier, identifiant de l'utilisateur
	 */
	public Article_Complet(int id_j, int id_u) {
		this.id_journal = id_j;
		this.id_user=id_u;

		// ************************** Cr�ation de la fen�tre
		// ****************************
		setBounds(100, 100, 636, 471);
		panel_principal = new JPanel();
		panel_principal.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(panel_principal);
		panel_principal.setLayout(null);
		panel_principal.setBackground(Color.WHITE);
		panel_principal.setBounds(0, 0, 620, 432);

		// ************************** Ajout du bouton retour
		// *************************************
		JButton Retour = new JButton("Retour");
		Retour.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				setVisible(false);

			}
		});
		Retour.setBounds(496, 28, 114, 29);
		panel_principal.add(Retour);

		// *************************** Ajout de l'image Gnews
		// **************************************
		JLabel image_gnews = new JLabel(new ImageIcon(Article_Complet.class.getResource("res/gnews.png")));
		image_gnews.setBounds(33, 11, 174, 46);
		panel_principal.add(image_gnews);

		// *************************** Ajout du scrollPane (panneau pour avoir
		// les barres verticales et horizontales)*****
		JScrollPane scrollPane = new JScrollPane();
		scrollPane.setBounds(160, 75, 450, 346);
		panel_principal.add(scrollPane);

		// *************************** Ajout de la zone de texte (affichage de
		// l'article complet)*************************
		JEditorPane texte_article_complet = new JEditorPane();
		texte_article_complet.setEditable(false);
		scrollPane.setViewportView(texte_article_complet); // on ajoute la zone
															// de texte dans le
															// scrollpane

		// ************************** Ajout d'un second scrollpane pour la zone
		// o� l'on affiche les noms propres****************
		JScrollPane scrollPane_np = new JScrollPane();
		scrollPane_np.setBounds(10, 75, 140, 346);
		panel_principal.add(scrollPane_np);

		// ************************** Ajout de la seconde zone de texte pour les
		// noms propre *******************
		final JTextPane texte_np = new JTextPane();
		texte_np.setForeground(new Color(128, 128, 128));
		texte_np.setFont(new Font("Bodoni MT", Font.BOLD | Font.ITALIC, 14));
		texte_np.setBackground(new Color(176, 224, 230));
		texte_np.setEditable(false);
		scrollPane_np.setViewportView(texte_np);

		// ************************** Ajout d'un listener lorsque l'on double
		// clique avec la souris => liens wikip�dia ***********
		texte_np.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				if (e.getClickCount() == 2) { // ==2 => double clique
					lien_wiki = pretraitement(texte_np.getSelectedText()); // cr�ation
																			// du
																			// lien
																			// wikip�dia
					BrowserControl.openWebpage(lien_wiki); // on lance le lien
															// wikip�dia
				}
			}
		});

		// ************************* Ajout des boutons like (un normal et un
		// quand on like) *************************
		
		pouce = new JButton(new ImageIcon(Article_Complet.class.getResource("res/pouce_bleu.jpeg")));
		pouce2 = new JButton("");
		pouce2.setIcon(new ImageIcon(Article_Complet.class.getResource("res/pouce_vert.jpg")));
		
		if(id_user == 0){
			pouce.setVisible(false);
			pouce2.setVisible(false);
			
		}
		else{
			pouce.setForeground(Color.BLACK);
			pouce.setBackground(Color.WHITE);

			pouce2.setBounds(433, 18, 53, 46);
			panel_principal.add(pouce2);
			pouce2.setVisible(false);
			
		}

		// ************************* Ajout du listener sur le clique du bouton
		// like **************
		pouce.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				liker(id_journal,id_user);
				pouce.setVisible(false);
				pouce2.setVisible(true);
			}
		});
		pouce.setBounds(433, 18, 53, 46);
		panel_principal.add(pouce);

		// ************************* Connexion a la base pour afficher l'article
		// complet ***********
		try {
			String pilote = "com.mysql.jdbc.Driver";
			Class.forName(pilote);

			Connection connexion = DriverManager.getConnection(
					"jdbc:mysql://localhost:3306/test", "root", "");
			//System.out.println("Connexion r�ussie!");
			Statement instruction = connexion.createStatement();
			ResultSet resultat = instruction
					.executeQuery("SELECT * FROM journal WHERE ID = '"
							+ id_journal + "'");

			DefaultListModel liste = new DefaultListModel();

			String np = "";
			texte_article_complet.setEditorKit(new javax.swing.text.html.HTMLEditorKit());

			while (resultat.next()) {

				np = resultat.getString("NP");

				String articleComp = resultat.getString("Article");
				
				articleComp = articleComp.replaceAll("retourALaLigne", "\n");
				articleComp = articleComp.replaceAll("This entry passed through the Full-Text RSS service _ if this is your content and you're reading it on someone else's site, please read the FAQ at fivefilters.org/content-only/faq.php#publishers.","");
				articleComp = articleComp.replaceAll("�", "�");
				articleComp = articleComp.replaceAll("�", "");
				articleComp = articleComp.replaceAll("�", "�");
				articleComp = articleComp.replaceAll("�", "�");
				articleComp = articleComp.replaceAll("�", "�");
				articleComp = articleComp.replaceAll("�", "�");
				articleComp = articleComp.replaceAll("œ", "�");
				articleComp = articleComp.replaceAll("—", "-");
				articleComp = articleComp.replaceAll("•", "�");
				articleComp = articleComp.replaceAll("�", "�");
				articleComp = articleComp.replaceAll("�", "�");
				
				String nom_journal = resultat.getString("nom_journal");
				String titre_article = resultat.getString("Titre_article");
				
				texte_article_complet.setText("<font face='Tahoma' color='#87CEEB' size='6'><center><b>"+titre_article+"</b></center></font><br/>"+
						"<font face='Tahoma' size='4'><u>"+nom_journal+"</font></u><br/>"+ 
						"<font face='Tahoma' size='4'>"+articleComp + "</font><br/>");

				np = np.replaceAll(" ", "\n");

				liste.addElement(np);

				String text = "";
				text = text + np;
				texte_np.setText(text);

			}

		} catch (ClassNotFoundException exc) {
			exc.printStackTrace();
		} catch (SQLException exc) {
			exc.printStackTrace();
		}

	}

	
	/**
	 * On g�n�re le lien wikip�dia � partir de "mot"
	 * @param mot : string � traiter
	 * @return : on retourne une URL
	 */
	public static URL pretraitement(String mot) {
		mot = mot.replace("�", "");

		String s = "http://fr.wikipedia.org/wiki/" + mot; // traiter les mots
															// compos�s pour
															// afficher des
															// underscore.
															// Sp�cial:Recherche

		try {
			lien_wiki = new URL(s);
		} catch (MalformedURLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		return lien_wiki;
	}


	/**
	 * M�thode du like : On se connecte a la base pour pouvoir enregistrer l'article lik� dans la base
	 * @param idj : entier, identifiant du journal
	 * @param idu : entier, identifiant de l'utilisateur
	 */
	public static void liker(int idj, int idu) {
		try {

			String pilote = "com.mysql.jdbc.Driver";
			Class.forName(pilote);

			Connection connexion = DriverManager.getConnection(
					"jdbc:mysql://localhost:3306/test", "root", "");
			Statement instruction = connexion.createStatement();

			List<Mots> mots_cles = new ArrayList<Mots>();
			
			
			mots_cles = GestionJournalPerso.trierTitresLikes(connexion, idu);
			GestionJournalPerso.insertionMotsLikesBase(connexion,mots_cles,idu);
			
			String requete = "INSERT INTO likes (ID, id_journal, id_utilisateur)"
					+ " VALUES (?,?,?)";
			PreparedStatement prestatement = connexion
				.prepareStatement(requete);
			prestatement.setString(1, null);
			prestatement.setInt(2, idj);
			prestatement.setInt(3, idu);
			prestatement.executeUpdate();
			
		} catch (Exception e) {
			System.out.println("Erreur table like: " + e);
		}
		
	}
}
