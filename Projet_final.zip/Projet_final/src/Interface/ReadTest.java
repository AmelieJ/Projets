package Interface;

import model.NomsPropres;
import model.ListeFlux;
//import test_projet.model.MessageFlux;
import model.Recup_article;
import read.RecupFluxRSS;

import java.sql.*;

/**
 *  M�thodes qui permettent de v�rifier s�il y a des doublons dans la liste des articles. 
 *  En effet, au chargement des articles dans la base de donn�es, ils ne viennent s�enregistrer 
 *  qu�une seule fois dans la table, m�me si ces articles sont encore pr�sents 
 *  dans la liste des flux. 
 * @author Maude
 *
 */
public class ReadTest {
	/**
	 * On cr�e le flux
	 * @param flux : string 
	 * @param idJ : entier, identifiant du journal
	 * @param nomJ : string : nom du journal
	 * @param conn : la connexion
	 */
	public static void flux(String flux, int idJ, String nomJ, java.sql.Connection conn) {
		RecupFluxRSS parser = new RecupFluxRSS(flux);

		ListeFlux ListeFlux = parser.readListeFlux();
		System.out.println(ListeFlux);
		// On se connecte � la base de donn�es grace au driver
		try {
			int nbflux = ListeFlux.entries.size();
			for (int i = 0; i < nbflux; i++) {

				verifDoublons(conn, idJ,nomJ, i);
			}
			ListeFlux = null;
		} catch (Exception e) {
			System.out.println("Erreur d'ecriture:  " + e);
			System.exit(-1);
		}

	}

	/**
	 * M�thode pour v�rifier s'il n'y a pas de doublons lors de la r�cup�rations des journaux
	 * @param conn : la connexion
	 * @param idJ : entier, identifiant du journal
	 * @param nomJ : string , nom du journal
	 * @param i : entier
	 */
	public static void verifDoublons(java.sql.Connection conn, int idJ,String nomJ, int i) {
		try {
			// Recuperation de l article 
			
			Recup_article article = new Recup_article();
			String Article = article.getcontent(ListeFlux.entries.get(i).link);
			
			String NP =NomsPropres.parcourirArticle(Article);
			//String NP="nnn";
			
			// on insere les flux dans une table provisoire
			String requete = "INSERT INTO prov " + "VALUES (?,?,?,?,?,?,?,?,?,?,?,?)";
			PreparedStatement prestatement = conn.prepareStatement(requete);
			prestatement.setString(1, null);
			prestatement.setInt(2, idJ);
			prestatement.setString(3, nomJ);
			prestatement.setString(4, ListeFlux.entries.get(i).title);
			prestatement.setString(5, ListeFlux.entries.get(i).pubDate);
			prestatement.setString(6, ListeFlux.entries.get(i).description);
			prestatement.setString(7, ListeFlux.entries.get(i).link);
			prestatement.setString(8, ListeFlux.entries.get(i).author);
			prestatement.setString(9, ListeFlux.entries.get(i).Item);
			prestatement.setString(10, Article);
			prestatement.setString(11, NP);
			prestatement.setInt(12, 0);

			prestatement.executeUpdate();
			
		} catch (Exception e) {
			System.out.println("Erreur table prov: " + e);
		}

		try {
			// on compare la table provisoire � la table journal et on insere les nouvelles valeurs dans le journal
			String requete2 = "INSERT INTO journal (id_journal,nom_journal,Titre_article,Date,Description,Lien,Auteur,Item, Article,NP,HotTopic)" + 
					"SELECT id_journal,nom_journal,Titre_article,Date,Description,Lien,Auteur,Item,Article,NP,HotTopic FROM prov WHERE Titre_article NOT IN (SELECT Titre_article FROM journal) ";
			Statement statement = conn.createStatement();
			statement.executeUpdate(requete2);
			
			String requete3 = "TRUNCATE prov";
			Statement statement3 = conn.createStatement();
			statement3.executeUpdate(requete3);
			
		} catch (Exception e) {
			System.out.println("Erreur nouvelle table " + e);
		}

	}

}