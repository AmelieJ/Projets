package Interface;

import java.awt.Color;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.Arrays;

import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JPasswordField;
import javax.swing.JTextField;
import javax.swing.JTextPane;
import javax.swing.border.LineBorder;
import javax.swing.border.MatteBorder;

/**
 * Classe qui permet de cr�er la fen�tre de cr�ation de compte
 * @author Maude
 *
 */
public class Panel_CreerCompte extends JPanel {

	private JTextField login2;
	private JPasswordField password2;
	private JFrame fenetre;
	private int id_user;
	private JPasswordField confirm_motdepasse;
	
	/**
	 * Cr�ation de la fen�tre
	 * @param f : JFrame
	 */
	public Panel_CreerCompte(JFrame f) {

		this.fenetre = f;
	
		this.setBounds(0, 0, 661, 529);
		this.setBackground(Color.WHITE);
		this.setBorder(new LineBorder(new Color(0, 0, 0), 3, true));
		this.setLayout(null);

		JTextPane txtpnCrezVotreCompte = new JTextPane();
		txtpnCrezVotreCompte.setEditable(false);
		txtpnCrezVotreCompte.setForeground(new Color(112, 128, 144));
		txtpnCrezVotreCompte.setFont(new Font("Lucida Sans Unicode", Font.BOLD,
				18));
		txtpnCrezVotreCompte.setText("Cr\u00E9ez votre compte Gnews");
		txtpnCrezVotreCompte.setBounds(188, 165, 283, 38);
		this.add(txtpnCrezVotreCompte);

		JButton btnC = new JButton("Cr\u00E9er");
		btnC.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				creercompte(e);

			}
		});
		btnC.setBounds(250, 343, 126, 29);
		this.add(btnC);

		JPanel panel_4 = new JPanel();
		panel_4.setBorder(new MatteBorder(1, 1, 1, 1,
				(Color) new Color(0, 0, 0)));
		panel_4.setBounds(141, 214, 357, 118);
		this.add(panel_4);
		panel_4.setLayout(null);

		JLabel lblLogin = new JLabel("Login");
		lblLogin.setBounds(38, 13, 64, 17);
		panel_4.add(lblLogin);

		JLabel lblMotDePasse = new JLabel("Mot de passe");
		lblMotDePasse.setBounds(38, 41, 95, 17);
		panel_4.add(lblMotDePasse);

		login2 = new JTextField();
		login2.setBounds(235, 11, 115, 20);
		panel_4.add(login2);
		login2.setColumns(10);

		password2 = new JPasswordField();
		password2.setBounds(235, 39, 115, 20);
		panel_4.add(password2);
		
		JLabel mot_de_passe2 = new JLabel("Confirmez le mot de passe");
		mot_de_passe2.setBounds(38, 69, 173, 17);
		panel_4.add(mot_de_passe2);
		
		confirm_motdepasse = new JPasswordField();
		confirm_motdepasse.setBounds(235, 70, 115, 20);
		panel_4.add(confirm_motdepasse);

		JLabel lblNewLabel_2 = new JLabel(new ImageIcon(Panel_CreerCompte.class.getResource("res/gnews.png")));
		lblNewLabel_2.setBounds(188, 38, 240, 88);
		this.add(lblNewLabel_2);

		JButton btnAnnuler = new JButton("Annuler");
		btnAnnuler.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				fenetre.getContentPane().removeAll();
				fenetre.getContentPane().add(new Panel_Accueil(fenetre));
				fenetre.repaint();
			}
		});
		btnAnnuler.setBounds(250, 392, 126, 29);
		this.add(btnAnnuler);
		
		
	}
	
	
	/**
	 * M�thode pour cr�er le compte
	 * @param e : une actionEvent
	 */
	public void creercompte(ActionEvent e) {
		String nom = login2.getText();
		char[] pass = password2.getPassword();
		char[] pass2 = confirm_motdepasse.getPassword();
		String passString = new String(pass);

		String pilote = "com.mysql.jdbc.Driver";
		
		String test_pass=Arrays.toString(password2.getPassword());//get the char array of password and convert to string represenation
		String test_pass2=Arrays.toString(confirm_motdepasse.getPassword());
		
		if(!(test_pass2.equals(test_pass))){
			JOptionPane.showMessageDialog(this,
					"Les 2 mots de passe entr�s ne sont pas identiques",
					"Error Message", JOptionPane.ERROR_MESSAGE);
		}
		else{
			
		try {
			Class.forName(pilote);

			Connection connexion = DriverManager.getConnection(
					"jdbc:mysql://localhost:3306/test", "root", "");

			String requete = "SELECT login FROM utilisateurs WHERE login = ?";
			PreparedStatement statement = connexion.prepareStatement(requete);
			statement.setString(1, nom);
			ResultSet result = statement.executeQuery();
			String user = " ";
			while (result.next()) {
				user = result.getString("login");
			}

			if (!(nom.equals(user))) { // si le login n est pas deja dans la
				// table
				// insere le nouvel utilisateur dans la table

				String requete2 = "INSERT INTO utilisateurs "
						+ "VALUES (?,?,?,?,?,?)";
				PreparedStatement prestatement = connexion
						.prepareStatement(requete2);
				prestatement.setString(1, null);
				prestatement.setString(2, nom);
				prestatement.setString(3, passString);
				prestatement.setString(4, "000000000");
				prestatement.setString(5, "");
				prestatement.setString(6, "");
				prestatement.executeUpdate();
				System.out.println("Nouvel utilisateur enregistr�!");
				JOptionPane.showMessageDialog(this,
						"Cr�ation de compte r�ussie!");
				fenetre.getContentPane().removeAll();
				fenetre.getContentPane().add(new Panel_Connexion(fenetre));
				fenetre.repaint();
			} else {
				JOptionPane.showMessageDialog(this,
						"Le nom d'utilisateur existe d�j�, entrez-en un autre",
						"Error Message", JOptionPane.ERROR_MESSAGE);

			}
		} catch (Exception ex) {
			System.out.println("Erreur enregistrement utilisateur " + ex);
		}
	}
	}
}
