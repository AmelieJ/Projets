package Interface;

import java.awt.EventQueue;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import javax.swing.ImageIcon;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;

import HotTopic.GestionJournalPerso;
import HotTopic.MotsLikes;

import javax.swing.JTextPane;

import java.awt.Color;

import javax.swing.JEditorPane;

import java.awt.Font;

import javax.swing.JButton;

import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

import javax.swing.JScrollPane;

/**
 * La classe Profil_user est utilis�e pour afficher le profil des utilisateurs:
 * On affiche le login, les abonnements et les mots correspondants aux th�mes
 * favoris de l'utilisateur dont l'identifiant est pass� en param�tre
 * 
 * @author Am�lie
 * 
 */
public class Profil_user extends JFrame {

	private JPanel contentPane;
	private int id;


	/**
	 * Cr�ation de la fen�tre
	 * @param id_user : entier, l'identifiant de l'utilisateur
	 */
	public Profil_user(int id_user) {

		this.id = id_user;

		setBounds(100, 100, 587, 382);
		contentPane = new JPanel();
		contentPane.setBackground(Color.WHITE);
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);

		JLabel img_gnews = new JLabel(new ImageIcon(Profil_user.class.getResource("res/gnews.png")));
		img_gnews.setBounds(21, 24, 169, 58);
		getContentPane().add(img_gnews);

		JEditorPane titre = new JEditorPane();
		titre.setForeground(new Color(0, 139, 139));
		titre.setFont(new Font("Georgia", Font.BOLD | Font.ITALIC, 20));
		titre.setText("Profil Utilisateur");
		titre.setEditable(false);
		titre.setBounds(200, 34, 187, 40);
		contentPane.add(titre);

		JButton Retour = new JButton("Retour");
		Retour.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				setVisible(false);
			}
		});
		Retour.setBounds(429, 34, 106, 25);
		contentPane.add(Retour);

		JScrollPane scrollAbonnement = new JScrollPane();
		scrollAbonnement.setBounds(48, 137, 179, 182);
		contentPane.add(scrollAbonnement);

		JEditorPane Abonnement = new JEditorPane();
		Abonnement.setFont(new Font("Times New Roman", Font.PLAIN, 14));
		Abonnement.setEditable(false);
		scrollAbonnement.setViewportView(Abonnement);

		JTextPane user = new JTextPane();
		user.setForeground(new Color(32, 178, 170));
		user.setFont(new Font("Lucida Bright", Font.ITALIC, 15));
		user.setEditable(false);
		user.setBounds(210, 69, 153, 25);
		contentPane.add(user);

		JTextPane txtpnVosAbonnements = new JTextPane();
		txtpnVosAbonnements.setEditable(false);
		txtpnVosAbonnements.setForeground(new Color(95, 158, 160));
		txtpnVosAbonnements.setFont(new Font("Lucida Bright", Font.BOLD, 14));
		txtpnVosAbonnements.setText("Vos abonnements:");
		txtpnVosAbonnements.setBounds(10, 106, 167, 20);
		contentPane.add(txtpnVosAbonnements);

		JScrollPane scrollmots = new JScrollPane();
		scrollmots.setBounds(331, 137, 179, 182);
		contentPane.add(scrollmots);

		JEditorPane mots = new JEditorPane();
		mots.setFont(new Font("Times New Roman", Font.PLAIN, 14));
		mots.setEditable(false);
		scrollmots.setViewportView(mots);

		JTextPane txtpnVosThmesFavoris = new JTextPane();
		txtpnVosThmesFavoris.setEditable(false);
		txtpnVosThmesFavoris.setText("Vos th\u00E8mes favoris:");
		txtpnVosThmesFavoris.setForeground(new Color(95, 158, 160));
		txtpnVosThmesFavoris.setFont(new Font("Lucida Bright", Font.BOLD, 14));
		txtpnVosThmesFavoris.setBounds(260, 106, 167, 20);
		contentPane.add(txtpnVosThmesFavoris);

		try {

			Class.forName("com.mysql.jdbc.Driver").newInstance();
			java.sql.Connection conn;
			conn = java.sql.DriverManager.getConnection(
					"jdbc:mysql://localhost:3306/test", "root", "");
			System.out.println("Connexion r�ussie  !!!");
			System.out.println(" ");

			// Recuperation profil
			String requete = "SELECT * FROM utilisateurs WHERE ID = ?";
			PreparedStatement statement = conn.prepareStatement(requete);
			statement.setInt(1, id);
			ResultSet result = statement.executeQuery();

			int tab[] = new int[9]; // tableau contenant les valeurs
									// d'abonnement
			String abonnement = "";
			String mots_likes = "";
			String freq_mots_likes = "";

			while (result.next()) {
				// mots lik�s
				mots_likes = result.getString("mots_likes");
				freq_mots_likes = result.getString("freq_mots_likes");
				List<MotsLikes> liste_mots = new ArrayList<MotsLikes>();
				GestionJournalPerso.trierMots(mots_likes, freq_mots_likes,
						liste_mots);

				// liste des journaux abonn�s
				abonnement = result.getString("abonnement");
				for (int i = 0; i < 9; i++) {
					tab[i] = abonnement.charAt(i) - 48;
				}

				// Affichage profil

				String login = "Utilisateur: " + result.getString("login");
				user.setText(login);
				String res = "";
				for (int i = 0; i < 9; i++) {
					// affiche les noms des journaux auxquels l utilisateur est
					// abonn�
					try {
						String requete2 = "SELECT nom FROM listejournaux WHERE ID=?";
						PreparedStatement statement2 = conn
								.prepareStatement(requete2);
						statement2.setInt(1, tab[i]);
						ResultSet result2 = statement2.executeQuery();
						int un = 0;

						while (result2.next() && un < 1) {

							res = res + result2.getString("nom") + "\n";
							un++;
						}
					} catch (Exception e) {
						e.printStackTrace();
						System.out
								.println("Erreur r�cuperation noms journaux: "
										+ e);
					}
				}
				Abonnement.setText(res);;
				// affiche les 7 premiers mots de la liste de likes
				String res2 = "";
				
				
				 for (int i = 0; i < 7; i++) { res2 = res2 +
				 liste_mots.get(i).getMot() + " \n "; }
				 
				mots.setText(res2);
			}

		} catch (SQLException e) {
			System.out.println("Erreur de recuperation de profil: " + e);
			e.printStackTrace();
		} catch (InstantiationException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		} catch (IllegalAccessException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		} catch (ClassNotFoundException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}

	}
}
