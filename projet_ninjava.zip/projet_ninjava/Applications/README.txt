##################################### MANUEL D'INSTALLATION #####################################


***********Fichiers mis � disposition************************************************************

*	- Gnews.jar : executable jar					    			*

*	- test.sql : base de donn�e � importer sous PhpMyAdmin depuis Wampserver2.4-x86		*

*	- Wampserver2.4-x86.exe: fichier d'installation de winamp			    	*
*************************************************************************************************
- Le JRE est indispensable pour ex�cuter une application java, si n�cessaire le t�l�charger � l'adresse suivante : 										http://www.java.com/fr/download/


- Installation de Wampserver2.4-x86

- Lancer Wampserver2.4-x86

- En bas � droite du bureau, clic gauche sur Wampserver et cliquer sur phpMyAdmin

- Se loguer en tant que : login = "root" mdp = "" et cliquer sur Executer

- Cliquer sur la base "creation_table" � gauche sous l'option "Tables r�centes"

- CLiquer sur l'onglet "Importer", choisir le fichier test.sql et cliquer sur Executer

- Le param�trage de l'application est termin�, lancer l'executable Gnews.jar

- Se fier � la documentation d'installation pour utiliser l'application